-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2024 at 04:32 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sdg1`
--

-- --------------------------------------------------------

--
-- Table structure for table `1_1_1`
--
-- Creation: Apr 29, 2024 at 01:49 PM
-- Last update: Apr 29, 2024 at 01:59 PM
--

CREATE TABLE `1_1_1` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `year_of_publication` int(4) DEFAULT NULL,
  `total_citations` int(11) DEFAULT NULL,
  `co-authored_country` text NOT NULL,
  `country_income` enum('Low income','Lower-middle income','Upper-middle income','High income') DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_1_1`
--

INSERT INTO `1_1_1` (`id`, `title`, `author`, `year_of_publication`, `total_citations`, `co-authored_country`, `country_income`, `Survey_datetimestamp`) VALUES
(1, 'a', 'a', 2001, 454, 'a', 'Low income', '2024-04-29 13:59:24');

-- --------------------------------------------------------

--
-- Table structure for table `1_2_1`
--
-- Creation: Apr 29, 2024 at 01:51 PM
-- Last update: Apr 29, 2024 at 01:51 PM
--

CREATE TABLE `1_2_1` (
  `studentid` int(11) NOT NULL,
  `Name` text DEFAULT NULL,
  `SrCode` varchar(10) NOT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year','Fifth Year') DEFAULT NULL,
  `Section` int(10) NOT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `PrivateScholarship` tinyint(1) DEFAULT NULL,
  `GovtScholarship` tinyint(1) DEFAULT NULL,
  `OtherScholarship` tinyint(1) DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `FamilyMemberOf4Ps` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_2_1`
--

INSERT INTO `1_2_1` (`studentid`, `Name`, `SrCode`, `Year`, `Section`, `Gender`, `PrivateScholarship`, `GovtScholarship`, `OtherScholarship`, `LowIncomeFamily`, `FamilyMemberOf4Ps`, `Survey_datetimestamp`) VALUES
(6, '1', '0', 'Third Year', 0, 'Female', 0, NULL, 1, 1, 1, '2024-04-29 13:51:02'),
(7, '', '0', 'Third Year', 0, 'Female', 1, 1, 1, 1, 1, '2024-04-29 13:51:02'),
(8, '', '0', 'First Year', 0, 'Male', 0, 0, 0, 0, 0, '2024-04-29 13:51:02');

-- --------------------------------------------------------

--
-- Table structure for table `1_2_2`
--
-- Creation: Apr 29, 2024 at 01:51 PM
-- Last update: Apr 29, 2024 at 01:51 PM
--

CREATE TABLE `1_2_2` (
  `student_vouchers_id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `SrCode` varchar(10) NOT NULL,
  `Section` int(10) NOT NULL,
  `book_vouchers` tinyint(1) DEFAULT NULL,
  `computer_vouchers` tinyint(1) DEFAULT NULL,
  `school_supplies_vouchers` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_2_2`
--

INSERT INTO `1_2_2` (`student_vouchers_id`, `name`, `SrCode`, `Section`, `book_vouchers`, `computer_vouchers`, `school_supplies_vouchers`, `Survey_datetimestamp`) VALUES
(1, 'Ylad', 'a', 0, 0, 0, 0, '2024-04-29 13:51:52');

-- --------------------------------------------------------

--
-- Table structure for table `1_2_3`
--
-- Creation: Apr 29, 2024 at 01:51 PM
--

CREATE TABLE `1_2_3` (
  `PPA_id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `1_3_1`
--
-- Creation: Apr 29, 2024 at 01:51 PM
-- Last update: Apr 29, 2024 at 01:51 PM
--

CREATE TABLE `1_3_1` (
  `Student_ID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `SrCode` varchar(20) NOT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year') DEFAULT NULL,
  `Section` int(10) NOT NULL,
  `Course_Taken` enum('BSIT','BSBA','BSED') DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_3_1`
--

INSERT INTO `1_3_1` (`Student_ID`, `Name`, `SrCode`, `Gender`, `Year`, `Section`, `Course_Taken`, `LowIncomeFamily`, `Survey_datetimestamp`) VALUES
(1, 'a', '', 'Male', 'First Year', 0, 'BSBA', 1, '2024-04-29 13:51:52'),
(2, '1', 'a', 'Male', 'First Year', 0, 'BSIT', 0, '2024-04-29 13:51:52');

-- --------------------------------------------------------

--
-- Table structure for table `1_3_2`
--
-- Creation: Apr 29, 2024 at 01:51 PM
-- Last update: Apr 29, 2024 at 01:51 PM
--

CREATE TABLE `1_3_2` (
  `Name` varchar(255) DEFAULT NULL,
  `SrCode` int(10) NOT NULL,
  `YearGraduated` int(11) DEFAULT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Course_Taken` enum('BSIT','BSBA','BSED') DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_3_2`
--

INSERT INTO `1_3_2` (`Name`, `SrCode`, `YearGraduated`, `Gender`, `Course_Taken`, `LowIncomeFamily`, `Survey_datetimestamp`) VALUES
('A', 0, 0, 'Male', 'BSIT', 1, '2024-04-29 13:51:52'),
('A', 0, 0, 'Female', 'BSED', 0, '2024-04-29 13:51:52'),
('a', 0, 1232, 'Male', 'BSBA', 0, '2024-04-29 13:51:52');

-- --------------------------------------------------------

--
-- Table structure for table `1_3_3`
--
-- Creation: Apr 29, 2024 at 01:52 PM
--

CREATE TABLE `1_3_3` (
  `PPA_id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `1_3_4`
--
-- Creation: Apr 29, 2024 at 01:52 PM
-- Last update: Apr 29, 2024 at 01:52 PM
--

CREATE TABLE `1_3_4` (
  `Student_ID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `SrCode` varchar(10) NOT NULL,
  `Is_Employed` tinyint(1) DEFAULT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year') DEFAULT NULL,
  `Section` int(10) NOT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Employment_Working_Hours` int(11) DEFAULT NULL,
  `Employment_Work_Type` varchar(255) DEFAULT NULL,
  `Employment_Work_Place` varchar(255) DEFAULT NULL,
  `Is_Student_Assistant` tinyint(1) DEFAULT NULL,
  `SA_Length_of_Service` int(11) DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_3_4`
--

INSERT INTO `1_3_4` (`Student_ID`, `Name`, `SrCode`, `Is_Employed`, `Year`, `Section`, `Gender`, `Employment_Working_Hours`, `Employment_Work_Type`, `Employment_Work_Place`, `Is_Student_Assistant`, `SA_Length_of_Service`, `LowIncomeFamily`, `Survey_datetimestamp`) VALUES
(1, '', '', 1, 'First Year', 0, 'Male', 0, 'A', 'A', 1, 0, 1, '2024-04-29 13:52:38');

-- --------------------------------------------------------

--
-- Table structure for table `1_3_5`
--
-- Creation: Apr 29, 2024 at 02:19 PM
-- Last update: Apr 29, 2024 at 02:19 PM
--

CREATE TABLE `1_3_5` (
  `ID` int(11) NOT NULL,
  `IsForeignStudent` tinyint(1) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `SrCode` varchar(20) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year') DEFAULT NULL,
  `Section` varchar(50) DEFAULT NULL,
  `Course_Taken` enum('BSIT','BSBA','BSED') DEFAULT NULL,
  `fromlowincomecountry` tinyint(1) NOT NULL,
  `FinancialSupportfromcampus` tinyint(1) DEFAULT NULL,
  `SatisfactionLevel` enum('Very satisfied','Satisfied','Neutral','Dissatisfied','Very dissatisfied') DEFAULT NULL,
  `WouldRecommend` tinyint(1) DEFAULT NULL,
  `SurveyDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table ` 1_4_1`
--
-- Creation: Apr 29, 2024 at 01:54 PM
-- Last update: Apr 29, 2024 at 01:54 PM
--

CREATE TABLE ` 1_4_1` (
  `PPA_id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table ` 1_4_1`
--

INSERT INTO ` 1_4_1` (`PPA_id`, `PPA_title`, `PPA_description`, `PPA_COST`, `PPA_fundsource`, `Survey_datetimestamp`) VALUES
(1, 'asd', 'sadasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadsadasdas', 0.00, 'asdasdasdasdad ', '2024-04-29 13:54:51');

-- --------------------------------------------------------

--
-- Table structure for table `1_4_2`
--
-- Creation: Apr 29, 2024 at 01:54 PM
-- Last update: Apr 29, 2024 at 01:54 PM
--

CREATE TABLE `1_4_2` (
  `Startup_ID` int(11) NOT NULL,
  `Name` text DEFAULT NULL,
  `Received_Financial_Assistance` tinyint(1) DEFAULT NULL,
  `Financial_Assistance_Source` enum('Internally funded','Externally funded') DEFAULT NULL,
  `Total_Assistance_Amount` decimal(10,2) DEFAULT NULL,
  `Startup_Name` varchar(255) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_4_2`
--

INSERT INTO `1_4_2` (`Startup_ID`, `Name`, `Received_Financial_Assistance`, `Financial_Assistance_Source`, `Total_Assistance_Amount`, `Startup_Name`, `Survey_datetimestamp`) VALUES
(1, 'as', 1, 'Externally funded', 0.00, 'a', '2024-04-29 13:54:21');

-- --------------------------------------------------------

--
-- Table structure for table `1_4_3`
--
-- Creation: Apr 29, 2024 at 01:54 PM
--

CREATE TABLE `1_4_3` (
  `PPA_id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `columnquestion`
--
-- Creation: Apr 24, 2024 at 09:38 AM
-- Last update: Apr 29, 2024 at 02:26 PM
--

CREATE TABLE `columnquestion` (
  `id` int(11) NOT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `column_question` varchar(255) DEFAULT NULL,
  `question_direction` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `columnquestion`
--

INSERT INTO `columnquestion` (`id`, `column_name`, `column_question`, `question_direction`) VALUES
(1, 'title', 'Title: ', 'Title of the research'),
(2, 'author', 'Author: ', 'Author of the Research'),
(3, 'year_of_publication', 'Year of Publication: ', 'Format: YYYY'),
(4, 'total_citations', 'Total Citations: ', ''),
(5, 'Name', 'Name: ', '(for now optional to put name)'),
(6, 'Year', 'Year: ', NULL),
(7, ' Gender', ' Gender: ', NULL),
(8, 'TuitionAssistance', 'Do you Recieve any TuitionAssistance?', NULL),
(9, 'PrivateScholarship', 'If you are receiving tuition assistance/school financial aid, is it private funded financial aid/scholarship?', NULL),
(10, 'GovtScholarship', 'If you are receiving tuition assistance/school financial aid, is it provided by the government as a scholarship?', NULL),
(11, 'OtherScholarship', 'Do you Receive other Scholarship Aside From those two?', NULL),
(12, 'LowIncomeFamily', 'Do you consider your household to be low-income', NULL),
(13, 'FamilyMemberOf4Ps', 'Do you any have any family Members that member of 4P\'s?', NULL),
(14, 'book_vouchers', 'Have you received book vouchers to assist with your educational expenses?', NULL),
(15, 'computer_vouchers', 'Have you received vouchers to purchase computers or related equipment for your studies?', NULL),
(17, 'school_supplies_vouchers ', 'Have you received vouchers to obtain school supplies such as stationery, textbooks, or other educational materials?', NULL),
(18, 'PPA_title', 'Title of the PPA:', 'Name of the program/initiative.'),
(19, 'PPA_description', 'Short description:', 'Brief overview of the program\'s objectives and key features.'),
(20, 'PPA_COST', 'Total cost:', 'Total budget allocated for the program.'),
(21, 'PPA_fundsource', 'Fund source:', 'Source(s) of funding for the program.'),
(22, 'country_income', 'What do you perceive as the income level of co-authored country?', NULL),
(23, 'co-authored_country', 'Which country or countries was collaborate or co-authored with the research?', NULL),
(25, 'YearGraduated', 'Year Graduated:', 'format: YYYY '),
(26, 'Course_Taken', 'Course:', NULL),
(27, 'Is_Employed', 'Are you currently employed while studying?', NULL),
(28, 'Employment_Working_Hours', 'Employment Working Hours: ', 'Number of Working Hours per Week'),
(30, 'Employment_Length_of_Service', 'Length of Service:', 'in months'),
(31, 'Is_Student_Assistant', 'Are you a student assistant on campus?', NULL),
(32, 'SA_Length_of_Service', 'Length of Service:', 'in months'),
(33, 'Employment_Work_Type', 'Type of Work:', 'like: cashier, clerk, etc'),
(34, 'Employment_Work_Place', 'Workplace Name:', NULL),
(35, 'Total_Assistance_Amount', 'Please specify the total amount of financial assistance provided to your start-up:', NULL),
(36, 'Startup_Name', 'Would you be willing to share the name of your start-up that received financial assistance? ', 'Optional'),
(37, ' Financial_Assistance_Source', 'If yes, please specify the source of the financial assistance:', NULL),
(38, 'Received_Financial_Assistance ', 'Did your start-up receive financial assistance for its establishment?', NULL),
(39, 'IsForeignStudent ', 'Are you a foreign student at our campus?', NULL),
(40, 'SatisfactionLevel', 'What would you Rate Your Satisfaction on our Campus/Univerities?', NULL),
(41, 'WouldRecommend', 'Would you recommend our campus/Universirty to other students from your home countries?', NULL),
(42, 'FinancialSupportfromcampus', 'Are You Receiving Financial Support from our University/Campus?', NULL),
(43, 'fromlowincomecountry', 'Do you consider your home country to be from a low-income background?', NULL),
(44, 'SrCode', 'SR-CODE: ', NULL),
(45, 'Section', 'Section:', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `datasummary`
--
-- Creation: Apr 25, 2024 at 12:43 PM
-- Last update: Apr 29, 2024 at 10:27 AM
--

CREATE TABLE `datasummary` (
  `datasummary_id` int(11) NOT NULL,
  `datasummary_description` text DEFAULT NULL,
  `data_query` text DEFAULT NULL,
  `part_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datasummary`
--

INSERT INTO `datasummary` (`datasummary_id`, `datasummary_description`, `data_query`, `part_id`) VALUES
(2, 'Total Number of Student per year(Male/Female) and Overall Population : ', 'SELECT \r\n    CASE WHEN Year IS NULL THEN \'Total\' ELSE Year END AS Year,\r\n    SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS MaleStudents, \r\n    SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS FemaleStudents, \r\n    COUNT(*) AS TotalStudents \r\nFROM 1_2_1\r\nGROUP BY Year WITH ROLLUP;\r\n', 2),
(3, 'Total Number of Student who Receive any Tuition Assistance group by year (Male/Female):', 'SELECT Year, SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS MaleStudents, SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS FemaleStudents, COUNT(*) AS TotalStudents FROM ( SELECT Year, Gender FROM 1_2_1 WHERE PrivateScholarship = 1 OR GovtScholarship = 1 OR OtherScholarship = 1 ) AS YearGender GROUP BY Year UNION ALL SELECT \'Total\' AS Year, SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS MaleStudents, SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS FemaleStudents, COUNT(*) AS TotalStudents FROM ( SELECT Year, Gender FROM 1_2_1 WHERE PrivateScholarship = 1 OR GovtScholarship = 1 OR OtherScholarship = 1 ) AS YearGender;', 2),
(4, 'Proportion of Students Receiving Various Types of Tuition Assistance:', 'SELECT\r\n    \'Private Scholarship Only\' AS ScholarshipType,\r\n    SUM(PrivateScholarship) - SUM(PrivateScholarship AND GovtScholarship) AS TotalStudents,\r\n    CONCAT(ROUND((SUM(PrivateScholarship) - SUM(PrivateScholarship AND GovtScholarship)) / COUNT(*) * 100, 2), \'%\') AS Percentage\r\nFROM 1_2_1\r\nUNION ALL\r\nSELECT\r\n    \'Government Scholarship Only\' AS ScholarshipType,\r\n    SUM(GovtScholarship) - SUM(PrivateScholarship AND GovtScholarship) AS TotalStudents,\r\n    CONCAT(ROUND((SUM(GovtScholarship) - SUM(PrivateScholarship AND GovtScholarship)) / COUNT(*) * 100, 2), \'%\') AS Percentage\r\nFROM 1_2_1\r\nUNION ALL\r\nSELECT\r\n    \'Other Scholarship\' AS ScholarshipType,\r\n    SUM(OtherScholarship) AS TotalStudents,\r\n    CONCAT(ROUND((SUM(OtherScholarship) / COUNT(*)) * 100, 2), \'%\') AS Percentage\r\nFROM 1_2_1\r\nUNION ALL\r\nSELECT\r\n    \'Both Private and Government Scholarship\' AS ScholarshipType,\r\n    SUM(PrivateScholarship AND GovtScholarship) AS TotalStudents,\r\n    CONCAT(ROUND((SUM(PrivateScholarship AND GovtScholarship) / COUNT(*)) * 100, 2), \'%\') AS Percentage\r\nFROM 1_2_1;\r\n', 2),
(5, 'Students whose family is a member of 4Ps:', 'SELECT \r\n    IFNULL(Year, \'Total\') AS Year,\r\n    SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS MaleStudents,\r\n    SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS FemaleStudents,\r\n    COUNT(*) AS TotalStudents\r\nFROM \r\n   1_2_1\r\nWHERE \r\n    FamilyMemberOf4Ps = TRUE\r\nGROUP BY \r\n    Year\r\nWITH ROLLUP;\r\n', 2),
(6, 'Students from low-income families:', 'SELECT \r\n    IFNULL(Year, \'Total\') AS Year,\r\n    SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS MaleStudents,\r\n    SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS FemaleStudents,\r\n    COUNT(*) AS TotalStudents\r\nFROM \r\n    1_2_1\r\nWHERE \r\n    LowIncomeFamily = TRUE\r\nGROUP BY \r\n    Year\r\nWITH ROLLUP;\r\n', 2),
(7, 'Total number of other jlow-income support for students:', 'SELECT COUNT(*) AS ppa_count FROM 1_2_3', 4),
(8, 'Total number of PPAs implemented to improve community access to\nbasic services:', 'SELECT COUNT(*) AS ppa_count FROM 1_4_3;', 8),
(9, 'Total number of assistances provided to local start-up:', 'SELECT COUNT(*) AS ppa_count FROM 1_4_1;', 6),
(10, 'Total number of published research on poverty:', 'SELECT COUNT(*) AS NumberOfResearch\nFROM 1_1_1;', 1),
(11, 'Total number of published research co-authored with low or lower-\nmiddle income countries:', 'SELECT COUNT(*) AS NumberOfResearch\nFROM 1_1_1\nWHERE country_income IN (\'Low income\', \'Lower-middle income\');\n', 1),
(12, 'Total number of PPAs that supports low-income students: ', 'SELECT COUNT(*) AS ppa_count FROM 1_3_3;', 12),
(13, 'Total number of graduates: (male/female, per program)', 'SELECT \r\n    IFNULL(Course_Taken, \'Total\') AS Course_Taken,\r\n    SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS Male_Graduates,\r\n    SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS Female_Graduates,\r\n    COUNT(*) AS Total_Graduates\r\nFROM \r\n    1_3_2\r\nGROUP BY \r\n    Course_Taken WITH ROLLUP;\r\n', 11),
(15, 'Total and percentage number of low-income graduates:', 'SELECT \r\n    SUM(CASE WHEN LowIncomeFamily = TRUE THEN 1 ELSE 0 END) AS Total_LowIncome_Students,\r\n    COUNT(*) AS Total_Graduates,\r\n    (SUM(CASE WHEN LowIncomeFamily = TRUE THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS Percentage_LowIncome_Graduates\r\nFROM \r\n    1_3_2\r\n', 11),
(16, 'Total and percentage number of admitted students: (male/female, per program) are from low-income families:', 'SELECT \r\n    IFNULL(Course_Taken, \'Total\') AS Course_Taken,\r\n    COUNT(*) AS Total_Admitted_Students,\r\n    SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS Male_Admitted_Students,\r\n    SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS Female_Admitted_Students,\r\n    (SUM(CASE WHEN LowIncomeFamily = TRUE THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS Percentage_LowIncome_Admitted\r\nFROM \r\n    1_3_1\r\nGROUP BY \r\n    Course_Taken\r\nWITH ROLLUP;\r\n', 10),
(17, 'Total number of working students (male/female) and avg Working hours per Year level|:', 'SELECT\r\n    COALESCE(Year, \'Total\') AS Year,\r\n    SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS Male_Working_Students,\r\n    SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS Female_Working_Students,\r\n    AVG(Employment_Working_Hours) AS Average_Working_Hours\r\nFROM\r\n     1_3_4\r\nWHERE\r\n    Is_Employed = TRUE\r\nGROUP BY\r\n    Year WITH ROLLUP\r\nUNION ALL\r\nSELECT\r\n    \'Grand Total\' AS Year,\r\n    SUM(CASE WHEN Gender = \'Male\' THEN 1 ELSE 0 END) AS Male_Working_Students,\r\n    SUM(CASE WHEN Gender = \'Female\' THEN 1 ELSE 0 END) AS Female_Working_Students,\r\n    AVG(Employment_Working_Hours) AS Average_Working_Hours\r\nFROM\r\n     1_3_4\r\nWHERE\r\n    Is_Employed = TRUE;\r\n ', 13),
(18, 'Total and Percentage number of working students from low-income families:', 'SELECT\r\n    COUNT(*) AS Total_Working_Students_Low_Income,\r\n    COUNT(*) / (SELECT COUNT(*) FROM  1_3_4 WHERE Is_Employed = TRUE) * 100 AS Percentage_Low_Income\r\nFROM\r\n    1_3_4\r\nWHERE\r\n    Is_Employed = TRUE\r\n    AND LowIncomeFamily = TRUE;\r\n', 13),
(19, 'Total number of student assistants:', 'SELECT\r\n    IFNULL(Year, \'Total\') AS Year,\r\n    SUM(CASE WHEN Gender = \'Male\' AND Is_Student_Assistant = TRUE THEN 1 ELSE 0 END) AS Male_Student_Assistants,\r\n    SUM(CASE WHEN Gender = \'Female\' AND Is_Student_Assistant = TRUE THEN 1 ELSE 0 END) AS Female_Student_Assistants,\r\n    ROUND((SUM(CASE WHEN Is_Student_Assistant = TRUE THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS Percentage_Student_Assistants\r\nFROM\r\n     1_3_4\r\nGROUP BY\r\n    Year WITH ROLLUP;\r\n', 13),
(20, 'Total number of student assistants from low-income families:', 'SELECT\r\n    SUM(CASE WHEN Is_Student_Assistant = TRUE AND LowIncomeFamily = TRUE THEN 1 ELSE 0 END) AS Total_LowIncome_Student_Assistants,\r\n    ROUND((SUM(CASE WHEN Is_Student_Assistant = TRUE AND LowIncomeFamily = TRUE THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS Percentage_LowIncome_Student_Assistants\r\nFROM\r\n   1_3_4;\r\n', 13),
(21, 'Total number of students who received vouchers for books:', 'SELECT\r\n    COUNT(*) AS Total_Book_Vouchers_Recipients\r\nFROM\r\n   1_2_2\r\nWHERE\r\n    book_vouchers = TRUE;\r\n', 3),
(22, 'Total number of students who received vouchers for computers:', 'SELECT\r\n    COUNT(*) AS Total_Computer_Vouchers_Recipients\r\nFROM\r\n   1_2_2\r\nWHERE\r\n    computer_vouchers = TRUE;\r\n', 3),
(23, 'Total number of other jlow-income support for students:', 'SELECT\n    COUNT(*) AS Total_SchoolSupplies_Vouchers_Recipients\nFROM\n  1_2_2\nWHERE\n    school_supplies_vouchers = TRUE;\n', 3),
(24, 'Student population receives vouchers for study related\nexpenses:', 'SELECT\r\n    COUNT(*) AS Total_Students_With_Vouchers,\r\n    ROUND((COUNT(*) / (SELECT COUNT(*) FROM  1_2_2)) * 100, 2) AS Percentage_Students_With_Vouchers\r\nFROM\r\n     1_2_2\r\nWHERE\r\n    book_vouchers = TRUE OR computer_vouchers = TRUE OR school_supplies_vouchers = TRUE;\r\n', 3),
(25, 'Total number of start-ups provided with financial assistance:', 'SELECT \n    COUNT(*) AS Total_Startups_With_Assistance\nFROM \n   1_4_2\nWHERE \n    Received_Financial_Assistance = TRUE;\n', 7),
(26, 'Fund source: (internally/externally funded)', 'SELECT \n    Financial_Assistance_Source,\n    COUNT(*) AS Total_Startups,\n    ROUND((COUNT(*) / (SELECT COUNT(*) FROM 1_4_2 WHERE Received_Financial_Assistance = TRUE)) * 100, 2) AS Percentage\nFROM \n    1_4_2 WHERE \n    Received_Financial_Assistance = TRUE\nGROUP BY \n    Financial_Assistance_Source;\n', 7),
(27, 'List of start-up assisted financially:', 'SELECT \n    Startup_Name\nFROM \n     1_4_2\nWHERE \n    Received_Financial_Assistance = TRUE;\n', 7);

-- --------------------------------------------------------

--
-- Table structure for table `parttable`
--
-- Creation: Apr 28, 2024 at 08:11 AM
-- Last update: Apr 29, 2024 at 02:29 PM
--

CREATE TABLE `parttable` (
  `part_id` int(11) NOT NULL,
  `part_title` varchar(255) DEFAULT NULL,
  `research_topic_id` int(11) DEFAULT NULL,
  `table_ref` varchar(255) DEFAULT NULL,
  `part_description` text DEFAULT NULL,
  `partfillup_guide` text NOT NULL,
  `Type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parttable`
--

INSERT INTO `parttable` (`part_id`, `part_title`, `research_topic_id`, `table_ref`, `part_description`, `partfillup_guide`, `Type`) VALUES
(1, 'Research on poverty', 1, '1_1_1', 'The section 1.1.1 \"Research on poverty\" provides insights into the current state of research efforts focused on understanding and addressing poverty. It begins by highlighting the absence of published research on poverty, indicating a gap in academic exploration and discourse in this critical area.<br>\n\nMoreover, it notes the absence of collaborative research efforts between countries with low or lower-middle-income statuses, indicating potential opportunities for international cooperation and knowledge sharing in combating poverty.<br>\n\nThe section outlines key information such as the total number of published research studies, co-authored research with low-income countries, and sample topics that serve as potential avenues for further investigation.', 'This form gathers information related to research on poverty. Please provide details about the research study, including its title, author(s), year of publication, and total citations. Your accurate responses are essential for reliable data collection.', ''),
(2, 'Tuition assistance', 2, '1_2_1', 'The section \"1.2.1 Tuition Assistance\" provides an overview of financial aid and scholarship distribution among students. It examines the allocation of assistance by academic year and gender, emphasizing the importance of both private and government-funded scholarships. The data highlights the prevalence of government aid programs, particularly among students from low-income families, as evidenced by their reliance on these scholarships. This analysis offers insights into the efforts to ensure equitable access to education and the role of financial aid in fostering inclusive learning environments.', 'This form collects information about tuition assistance and financial aid received by students. Select your academic year and gender. Indicate whether your assistance is privately funded or provided by the government as a scholarship. Additionally, specify if you receive other scholarships aside from these. Answer whether your household is considered low-income and if any family members are part of the 4P\'s program. Your accurate responses will ensure the reliability and usefulness of the data collected.', ''),
(3, 'Vouchers for study related expenses', 2, '1_2_2', 'In section 1.2.2 titled \"Vouchers for Study Related Expenses,\" the focus is on the distribution of vouchers for various educational needs. The section highlights the allocation of vouchers for books, computers, and school supplies, detailing the number of students who received each type of voucher and the corresponding amount provided. ', '', ''),
(4, 'Other low-income support for students', 2, '1_2_3', 'Section 1.2.3, \"Other Low-Income Support for Students,\" introduces additional avenues of assistance tailored to support financially disadvantaged students beyond traditional scholarship and voucher programs. While specific programs are not detailed, the section outlines potential forms of aid that universities may offer. These include low-interest student loans, fee waivers for various expenses, and emergency funds to address unexpected financial hardships. By highlighting these initiatives, the section underscores the institution\'s commitment to fostering accessibility and equity in higher education by addressing the diverse financial needs of students from low-income backgrounds.', 'Fill in the form with accurate details about the program supporting financially disadvantaged students. Provide the program\'s name, a brief description of its objectives, total cost, and funding source(s). ', 'PPA'),
(6, 'Local Start-Up Assistance', 4, '1_4_1', '1.4.1 Local Start-Up Assistance aims to provide support to financially and socially sustainable businesses within the local community. Through various initiatives such as mentorship programs, training workshops, and access to university facilities, entrepreneurs receive valuable education and resources to help them succeed. The program encourages collaboration and networking among entrepreneurs, facilitates access to expertise and facilities, and promotes awareness of available resources through community outreach efforts. Overall, the goal is to foster an environment where new businesses can thrive and contribute to the local economy.', 'Fill in details about the program aiding the startup of sustainable businesses in the community. Provide the program\'s name, a brief overview of its support initiatives (like mentorship or workshops), total cost, and funding sources', 'PPA'),
(7, 'Local Start-up Financial Assistance', 4, '1_4_2', 'The \"Local Start-up Financial Assistance\" section outlines our institution\'s efforts in providing crucial support to budding entrepreneurs. While metrics such as the total number of start-ups assisted and the funding amount are essential for gauging our impact, understanding the source of funding—whether internal or external—helps us assess the sustainability and effectiveness of our initiatives. Each supported venture represents a unique narrative of ambition and community impact, contributing to economic growth, job creation, and innovation. Through these efforts, we aim to cultivate an environment where entrepreneurship thrives, driving both economic and social progress within our community.', 'Thank you for participating in our survey regarding financial assistance provided to local start-ups. Your responses will help us better understand our community\'s efforts in supporting financially and socially sustainable businesses. Please provide accurate information to ensure the reliability of our data.', ''),
(8, 'Programmes for services access (extension services)', 4, '1_4_3', 'In Section 1.4.3 Programmes for services access (extension services) focuses on organizing training or programs to enhance community access to basic services. These services encompass health and nutrition, child mortality, standard of living improvements such as access to cooking fuel, sanitation, drinking water, electricity, housing, and assets. The goal is to implement initiatives that address these essential needs, ultimately improving the overall well-being and quality of life within the community. Examples of such initiatives include community nutrition education programs, first-aid training, maternal and newborn health education, energy-efficient cooking technologies, solar electrification, and community-based asset-building programs. Through these efforts, the program aims to enhance access to vital services, promote health and safety, and contribute to sustainable development within the community.', 'Enter program details focused on improving access to essential services through training or initiatives. Provide program name, objectives, budget, and funding sources for effective data collection.', 'PPA'),
(9, 'Participation in policy addressing poverty', 5, '1_5_5', NULL, '', ''),
(10, 'Admission target of low-income students', 3, '1_3_1', 'This section outlines the institution\'s commitment to admitting students from low-income households, aiming to foster diversity and inclusivity within the campus community. By setting targets for the admission of low-income students, the institution seeks to provide equitable opportunities for all individuals, irrespective of socioeconomic background. While specific numerical targets and percentages are currently unavailable, the institution\'s dedication to admitting students from low-income families underscores its broader mission of promoting accessibility and affordability in higher education.', 'Provide accurate information regarding your gender, desired course, household income status, and academic year. Your cooperation is appreciated as we work towards promoting accessibility and inclusivity in higher education. This survey aims to gather data to inform our efforts in setting admission targets for low-income students, ensuring equitable opportunities for all individuals regardless of socioeconomic background.', ''),
(11, 'Grad/completion targets of low-income students', 3, '1_3_2', 'This section provides insights into the graduation/completion targets for students hailing from low-income households within the institution. The data outlines the total number of graduates, distinguishing between those from low-income backgrounds and others, and reveals that a significant proportion of graduates belong to low-income families. This underscores the importance of understanding and addressing the unique challenges faced by students from economically disadvantaged backgrounds to ensure their academic success and attainment of graduation goals.', 'As part of our commitment to understanding and addressing the challenges faced by students from economically disadvantaged backgrounds, we kindly ask graduated students to provide their insights on their household income status. Your responses will help us better tailor our support initiatives to meet the needs of our diverse student body. Please answer the following questions honestly and accurately. Thank you for your cooperation.', ''),
(12, 'Low-income student support', 3, '1_3_3', 'This section outlines the absence of a specific program or initiative focused on supporting low-income students within the institution. Without a designated Title, Short Description, Total Cost, or Fund Source, it suggests a gap in resources allocated towards aiding students from low-income backgrounds. The absence of such support can hinder their ability to successfully navigate university life and graduate. This highlights a potential area for improvement within the institution\'s framework to ensure equitable access and support for all students, regardless of socioeconomic status.', ' Establishing clear guidelines and procedures for filling out this section will ensure comprehensive documentation of initiatives aimed at supporting low-income students within the institution. add this part', 'PPA'),
(13, 'Student Employment', 3, '1_3_4', '\nThis section focuses on the institution\'s initiatives to monitor and support student employment, aiming to address their financial needs effectively. By tracking the employment status of students, the institution endeavors to provide targeted assistance to those in need. Additionally, it highlights efforts to engage students as assistants on campus, contributing to both their financial support and their overall educational experience. These measures underscore the institution\'s commitment to fostering a supportive environment for all students, particularly those facing economic challenges.', 'Direction:  Your input is vital to our understanding and support of student employment. Please fill out the applicable sections accurately. If you\'re currently employed or a student assistant, provide relevant details. Your cooperation helps us better assist students facing financial challenges.', ''),
(14, 'Student support from low-income countries', 3, '1_3_5', 'This section provides an overview of student support initiatives targeting individuals from low-income countries within our campus community. It outlines the current status of such support programs, including the total number of foreign students, the proportion from low-income countries, and the extent of financial assistance provided to them. Additionally, it highlights any specific grants or scholarships allocated to students from low-income backgrounds. This information serves as a snapshot of the efforts and resources allocated towards supporting students from economically disadvantaged regions, with the aim of fostering inclusivity and equal opportunities within our educational environment.', 'We\'re conducting a survey to gather insights on student support from low-income countries. Your input is crucial in helping us understand the needs of foreign students better and enhancing our support services. Your responses will aid us in tailoring our offerings to meet the specific requirements of students coming from low-income backgrounds.', '');

-- --------------------------------------------------------

--
-- Table structure for table `sdg1_indicators`
--
-- Creation: Apr 23, 2024 at 05:17 AM
--

CREATE TABLE `sdg1_indicators` (
  `topic_id` int(11) NOT NULL,
  `research_topic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sdg1_indicators`
--

INSERT INTO `sdg1_indicators` (`topic_id`, `research_topic`) VALUES
(1, 'Research on poverty'),
(2, 'Financial aid to low-income students'),
(3, 'University anti-poverty programmes'),
(4, 'Community anti-poverty programmes'),
(5, 'Policy addressing poverty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `1_1_1`
--
ALTER TABLE `1_1_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `1_2_1`
--
ALTER TABLE `1_2_1`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `1_2_2`
--
ALTER TABLE `1_2_2`
  ADD PRIMARY KEY (`student_vouchers_id`);

--
-- Indexes for table `1_2_3`
--
ALTER TABLE `1_2_3`
  ADD PRIMARY KEY (`PPA_id`);

--
-- Indexes for table `1_3_1`
--
ALTER TABLE `1_3_1`
  ADD PRIMARY KEY (`Student_ID`);

--
-- Indexes for table `1_3_3`
--
ALTER TABLE `1_3_3`
  ADD PRIMARY KEY (`PPA_id`);

--
-- Indexes for table `1_3_4`
--
ALTER TABLE `1_3_4`
  ADD PRIMARY KEY (`Student_ID`);

--
-- Indexes for table `1_3_5`
--
ALTER TABLE `1_3_5`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table ` 1_4_1`
--
ALTER TABLE ` 1_4_1`
  ADD PRIMARY KEY (`PPA_id`);

--
-- Indexes for table `1_4_2`
--
ALTER TABLE `1_4_2`
  ADD PRIMARY KEY (`Startup_ID`);

--
-- Indexes for table `1_4_3`
--
ALTER TABLE `1_4_3`
  ADD PRIMARY KEY (`PPA_id`);

--
-- Indexes for table `columnquestion`
--
ALTER TABLE `columnquestion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datasummary`
--
ALTER TABLE `datasummary`
  ADD PRIMARY KEY (`datasummary_id`),
  ADD KEY `part_id` (`part_id`);

--
-- Indexes for table `parttable`
--
ALTER TABLE `parttable`
  ADD PRIMARY KEY (`part_id`),
  ADD KEY `research_topic_id` (`research_topic_id`);

--
-- Indexes for table `sdg1_indicators`
--
ALTER TABLE `sdg1_indicators`
  ADD PRIMARY KEY (`topic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `1_1_1`
--
ALTER TABLE `1_1_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `1_2_1`
--
ALTER TABLE `1_2_1`
  MODIFY `studentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `1_2_2`
--
ALTER TABLE `1_2_2`
  MODIFY `student_vouchers_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `1_2_3`
--
ALTER TABLE `1_2_3`
  MODIFY `PPA_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `1_3_1`
--
ALTER TABLE `1_3_1`
  MODIFY `Student_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `1_3_3`
--
ALTER TABLE `1_3_3`
  MODIFY `PPA_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `1_3_4`
--
ALTER TABLE `1_3_4`
  MODIFY `Student_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `1_3_5`
--
ALTER TABLE `1_3_5`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table ` 1_4_1`
--
ALTER TABLE ` 1_4_1`
  MODIFY `PPA_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `1_4_2`
--
ALTER TABLE `1_4_2`
  MODIFY `Startup_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `1_4_3`
--
ALTER TABLE `1_4_3`
  MODIFY `PPA_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `columnquestion`
--
ALTER TABLE `columnquestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `datasummary`
--
ALTER TABLE `datasummary`
  MODIFY `datasummary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `datasummary`
--
ALTER TABLE `datasummary`
  ADD CONSTRAINT `datasummary_ibfk_1` FOREIGN KEY (`part_id`) REFERENCES `parttable` (`part_id`);

--
-- Constraints for table `parttable`
--
ALTER TABLE `parttable`
  ADD CONSTRAINT `parttable_ibfk_1` FOREIGN KEY (`research_topic_id`) REFERENCES `sdg1_indicators` (`topic_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
