document.addEventListener('DOMContentLoaded', function () {
    // Toggle Switch
    const container = document.querySelector('.container');
    const toggleSwitch = document.querySelector('.switch');

   
    const aside = document.querySelector('aside');
    const toggleMenu = document.querySelector('.toggle-menu');

    toggleMenu.addEventListener('click', () => {
        aside.classList.toggle('active');
        toggleMenu.classList.toggle('active');
    });

    // Dropdown Menu
    const mainMenus = document.querySelectorAll('.main-menu');

    mainMenus.forEach((mainMenu) => {
        const subMenu = mainMenu.nextElementSibling;

        if (subMenu) {
            mainMenu.addEventListener('click', () => {
                mainMenu.classList.toggle('active');
                subMenu.classList.toggle('active');
            });

            const subMenuItems = subMenu.querySelectorAll('.sub-menu-item');

            subMenuItems.forEach((subMenuItem) => {
                subMenuItem.addEventListener('click', () => {
                    const subSubMenu = subMenuItem.nextElementSibling;
                    if (subSubMenu) {
                        // Toggle the active class for the sub-sub-menu
                        subSubMenu.classList.toggle('active');
                    }
                    // Toggle the active class only for the clicked submenu item
                    subMenuItem.classList.toggle('active');

                    // Close other active submenu items
                    const otherSubMenuItems = Array.from(subMenuItem.parentElement.children).filter(item => item !== subMenuItem);
                    otherSubMenuItems.forEach(item => item.classList.remove('active'));
                });
            });
        }
    });
});



 // Check if content overflows and add scrollbar if necessary
 function checkOverflow(element) {
    if (element.scrollHeight > element.clientHeight) {
        element.classList.add('scrollable-content');
    } else {
        element.classList.remove('scrollable-content');
    }
}

// Call checkOverflow when the document is loaded
document.addEventListener('DOMContentLoaded', function() {
    checkOverflow(document.getElementById('section'));
});


// Re-check overflow on window resize
window.addEventListener('resize', function() {
    checkOverflow(document.getElementById('section'));
});


  // Get the button element
  var viewTableBtn = document.getElementById('viewTableBtn');

  // Get the table data container element
  var dataTableContainer = document.querySelector('.data-table-container');

  // Get the button element
  var viewTableBtn = document.getElementById('viewTableBtn');

  // Get the table data container element
  var dataTableContainer = document.querySelector('.data-table-container');

  // Add click event listener to the button
  viewTableBtn.addEventListener('click', function() {
      // Toggle the display style of the table data container
      if (dataTableContainer.style.display === 'none') {
          dataTableContainer.style.display = 'flex';
          viewTableBtn.textContent = 'Hide Table Data';

             // Scroll to the data-table-container
        dataTableContainer.scrollIntoView({ behavior: 'smooth' });
      } else {
          dataTableContainer.style.display = 'none';
          viewTableBtn.textContent = 'View Table Data';
      }
  });



