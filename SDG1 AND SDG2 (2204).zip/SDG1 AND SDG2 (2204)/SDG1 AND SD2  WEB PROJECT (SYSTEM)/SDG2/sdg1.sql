SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `1_1_1` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `year_of_publication` int(4) DEFAULT NULL,
  `total_citations` int(11) DEFAULT NULL,
  `co-authored_country` text NOT NULL,
  `country_income` enum('Low income','Lower-middle income','Upper-middle income','High income') DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_2_1` (
  `id` int(11) NOT NULL,
  `Name` text DEFAULT NULL,
  `SrCode` varchar(10) NOT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year','Fifth Year') DEFAULT NULL,
  `Section` int(10) NOT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `PrivateScholarship` tinyint(1) DEFAULT NULL,
  `GovtScholarship` tinyint(1) DEFAULT NULL,
  `OtherScholarship` tinyint(1) DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `FamilyMemberOf4Ps` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_2_2` (
  `id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `SrCode` varchar(10) NOT NULL,
  `Section` int(10) NOT NULL,
  `book_vouchers` tinyint(1) DEFAULT NULL,
  `computer_vouchers` tinyint(1) DEFAULT NULL,
  `school_supplies_vouchers` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_2_3` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_3_1` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `SrCode` varchar(20) NOT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year') DEFAULT NULL,
  `Section` int(10) NOT NULL,
  `Course_Taken` enum('BSIT','BSBA','BSED') DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_3_2` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `SrCode` int(10) NOT NULL,
  `YearGraduated` int(11) DEFAULT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Course_Taken` enum('BSIT','BSBA','BSED') DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_3_3` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_3_4` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `SrCode` varchar(10) NOT NULL,
  `Is_Employed` tinyint(1) DEFAULT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year') DEFAULT NULL,
  `Section` int(10) NOT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Employment_Working_Hours` int(11) DEFAULT NULL,
  `Employment_Work_Type` varchar(255) DEFAULT NULL,
  `Employment_Work_Place` varchar(255) DEFAULT NULL,
  `Is_Student_Assistant` tinyint(1) DEFAULT NULL,
  `SA_Length_of_Service` int(11) DEFAULT NULL,
  `LowIncomeFamily` tinyint(1) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_3_5` (
  `id` int(11) NOT NULL,
  `IsForeignStudent` tinyint(1) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `SrCode` varchar(20) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Year` enum('First Year','Second Year','Third Year','Fourth Year') DEFAULT NULL,
  `Section` varchar(50) DEFAULT NULL,
  `Course_Taken` enum('BSIT','BSBA','BSED') DEFAULT NULL,
  `fromlowincomecountry` tinyint(1) NOT NULL,
  `FinancialSupportfromcampus` tinyint(1) DEFAULT NULL,
  `SatisfactionLevel` enum('Very satisfied','Satisfied','Neutral','Dissatisfied','Very dissatisfied') DEFAULT NULL,
  `WouldRecommend` tinyint(1) DEFAULT NULL,
  `SurveyDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE ` 1_4_1` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_4_2` (
  `id` int(11) NOT NULL,
  `Name` text DEFAULT NULL,
  `Received_Financial_Assistance` tinyint(1) DEFAULT NULL,
  `Financial_Assistance_Source` enum('Internally funded','Externally funded') DEFAULT NULL,
  `Total_Assistance_Amount` decimal(10,2) DEFAULT NULL,
  `Startup_Name` varchar(255) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `1_4_3` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `columnquestion` (
  `id` int(11) NOT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `column_question` varchar(255) DEFAULT NULL,
  `question_direction` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `datasummary` (
  `datasummary_id` int(11) NOT NULL,
  `datasummary_description` text DEFAULT NULL,
  `data_query` text DEFAULT NULL,
  `part_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `parttable` (
  `part_id` int(11) NOT NULL,
  `part_title` varchar(255) DEFAULT NULL,
  `research_topic_id` int(11) DEFAULT NULL,
  `table_ref` varchar(255) DEFAULT NULL,
  `part_description` text DEFAULT NULL,
  `partfillup_guide` text NOT NULL,
  `Type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `sdg1_indicators` (
  `topic_id` int(11) NOT NULL,
  `research_topic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


ALTER TABLE `1_1_1`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_2_1`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_2_2`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_2_3`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_3_1`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_3_2`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_3_3`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_3_4`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_3_5`
  ADD PRIMARY KEY (`id`);

ALTER TABLE ` 1_4_1`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_4_2`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `1_4_3`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `columnquestion`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `datasummary`
  ADD PRIMARY KEY (`datasummary_id`),
  ADD KEY `part_id` (`part_id`);

ALTER TABLE `parttable`
  ADD PRIMARY KEY (`part_id`),
  ADD KEY `research_topic_id` (`research_topic_id`);

ALTER TABLE `sdg1_indicators`
  ADD PRIMARY KEY (`topic_id`);


ALTER TABLE `1_1_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_2_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_2_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_2_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_3_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_3_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_3_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_3_4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_3_5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE ` 1_4_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_4_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `1_4_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `columnquestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `datasummary`
  MODIFY `datasummary_id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `datasummary`
  ADD CONSTRAINT `datasummary_ibfk_1` FOREIGN KEY (`part_id`) REFERENCES `parttable` (`part_id`);

ALTER TABLE `parttable`
  ADD CONSTRAINT `parttable_ibfk_1` FOREIGN KEY (`research_topic_id`) REFERENCES `sdg1_indicators` (`topic_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
