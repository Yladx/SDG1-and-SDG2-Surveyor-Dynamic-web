-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 08:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sdg2`
--

-- --------------------------------------------------------

--
-- Table structure for table `1_2_3`
--

CREATE TABLE `1_2_3` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `1_2_3`
--

INSERT INTO `1_2_3` (`id`, `PPA_title`, `PPA_description`, `PPA_COST`, `PPA_fundsource`, `Survey_datetimestamp`) VALUES
(1, 'a', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa sa dsad as astanginaam oajk odasj opasjfioashfiuashfijas hfiau aishf uiasohf iouashf\r\nfasifhasifhasiuofas', 213.00, '213', '2024-04-29 18:29:22');

-- --------------------------------------------------------

--
-- Table structure for table `2_1_1`
--

CREATE TABLE `2_1_1` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `year_of_publication` int(4) DEFAULT NULL,
  `total_citations` int(11) DEFAULT NULL,
  `co-authored_country` text NOT NULL,
  `country_income` enum('Low income','Lower-middle income','Upper-middle income','High income') DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `columnquestion`
--

CREATE TABLE `columnquestion` (
  `id` int(11) NOT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `column_question` varchar(255) DEFAULT NULL,
  `question_direction` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `columnquestion`
--

INSERT INTO `columnquestion` (`id`, `column_name`, `column_question`, `question_direction`) VALUES
(1, 'title', 'Title: ', 'Title of the research'),
(2, 'author', 'Author: ', 'Author of the Research'),
(3, 'year_of_publication', 'Year of Publication: ', 'Format: YYYY'),
(4, 'total_citations', 'Total Citations: ', ''),
(5, 'Name', 'Name: ', '(for now optional to put name)'),
(6, 'Year', 'Year: ', NULL),
(7, ' Gender', ' Gender: ', NULL),
(8, 'TuitionAssistance', 'Do you Recieve any TuitionAssistance?', NULL),
(9, 'PrivateScholarship', 'If you are receiving tuition assistance/school financial aid, is it private funded financial aid/scholarship?', NULL),
(10, 'GovtScholarship', 'If you are receiving tuition assistance/school financial aid, is it provided by the government as a scholarship?', NULL),
(11, 'OtherScholarship', 'Do you Receive other Scholarship Aside From those two?', NULL),
(12, 'LowIncomeFamily', 'Do you consider your household to be low-income', NULL),
(13, 'FamilyMemberOf4Ps', 'Do you any have any family Members that member of 4P\'s?', NULL),
(14, 'book_vouchers', 'Have you received book vouchers to assist with your educational expenses?', NULL),
(15, 'computer_vouchers', 'Have you received vouchers to purchase computers or related equipment for your studies?', NULL),
(17, 'school_supplies_vouchers ', 'Have you received vouchers to obtain school supplies such as stationery, textbooks, or other educational materials?', NULL),
(18, 'PPA_title', 'Title of the PPA:', 'Name of the program/initiative.'),
(19, 'PPA_description', 'Short description:', 'Brief overview of the program\'s objectives and key features.'),
(20, 'PPA_COST', 'Total cost:', 'Total budget allocated for the program.'),
(21, 'PPA_fundsource', 'Fund source:', 'Source(s) of funding for the program.'),
(22, 'country_income', 'What do you perceive as the income level of co-authored country?', NULL),
(23, 'co-authored_country', 'Which country or countries was collaborate or co-authored with the research?', NULL),
(25, 'YearGraduated', 'Year Graduated:', 'format: YYYY '),
(26, 'Course_Taken', 'Course:', NULL),
(27, 'Is_Employed', 'Are you currently employed while studying?', NULL),
(28, 'Employment_Working_Hours', 'Employment Working Hours: ', 'Number of Working Hours per Week'),
(30, 'Employment_Length_of_Service', 'Length of Service:', 'in months'),
(31, 'Is_Student_Assistant', 'Are you a student assistant on campus?', NULL),
(32, 'SA_Length_of_Service', 'Length of Service:', 'in months'),
(33, 'Employment_Work_Type', 'Type of Work:', 'like: cashier, clerk, etc'),
(34, 'Employment_Work_Place', 'Workplace Name:', NULL),
(35, 'Total_Assistance_Amount', 'Please specify the total amount of financial assistance provided to your start-up:', NULL),
(36, 'Startup_Name', 'Would you be willing to share the name of your start-up that received financial assistance? ', 'Optional'),
(37, ' Financial_Assistance_Source', 'If yes, please specify the source of the financial assistance:', NULL),
(38, 'Received_Financial_Assistance ', 'Did your start-up receive financial assistance for its establishment?', NULL),
(39, 'IsForeignStudent ', 'Are you a foreign student at our campus?', NULL),
(40, 'SatisfactionLevel', 'What would you Rate Your Satisfaction on our Campus/Univerities?', NULL),
(41, 'WouldRecommend', 'Would you recommend our campus/Universirty to other students from your home countries?', NULL),
(42, 'FinancialSupportfromcampus', 'Are You Receiving Financial Support from our University/Campus?', NULL),
(43, 'fromlowincomecountry', 'Do you consider your home country to be from a low-income background?', NULL),
(44, 'SrCode', 'SR-CODE: ', NULL),
(45, 'Section', 'Section:', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `datasummary`
--

CREATE TABLE `datasummary` (
  `datasummary_id` int(11) NOT NULL,
  `datasummary_description` text DEFAULT NULL,
  `data_query` text DEFAULT NULL,
  `part_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parttable`
--

CREATE TABLE `parttable` (
  `part_id` int(11) NOT NULL,
  `part_title` varchar(255) DEFAULT NULL,
  `research_topic_id` int(11) DEFAULT NULL,
  `table_ref` varchar(255) DEFAULT NULL,
  `part_description` text DEFAULT NULL,
  `partfillup_guide` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parttable`
--

INSERT INTO `parttable` (`part_id`, `part_title`, `research_topic_id`, `table_ref`, `part_description`, `partfillup_guide`) VALUES
(1, 'Research on hunger', 1, NULL, NULL, ''),
(2, 'Total campus food waste', 2, NULL, NULL, ''),
(3, 'Food waste per capita', 2, NULL, NULL, ''),
(4, 'Proportion of students who experience hunger', 3, NULL, NULL, ''),
(5, 'Student food insecurity and hunger', 3, NULL, NULL, ''),
(6, 'Proportion of employees who experience hunger', 3, NULL, NULL, ''),
(7, 'Students and staff hunger interventions', 3, NULL, NULL, ''),
(8, 'Sustainable, healthy and affordable food choices on campus', 3, NULL, NULL, ''),
(9, 'Access to food security knowledge', 4, NULL, NULL, ''),
(10, 'Events for local farmers and food producers', 4, NULL, NULL, ''),
(11, 'Access of local farmers and food producers to University\r\nfacilities', 4, NULL, NULL, ''),
(14, 'Sustainable food purchases', 4, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `sdg2_indicators`
--

CREATE TABLE `sdg2_indicators` (
  `topic_id` int(11) NOT NULL,
  `research_topic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sdg2_indicators`
--

INSERT INTO `sdg2_indicators` (`topic_id`, `research_topic`) VALUES
(1, 'Research on hunger'),
(2, 'Campus food waste'),
(3, 'Student and employee\r\nhunger'),
(4, 'National Hunger');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `1_2_3`
--
ALTER TABLE `1_2_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_1_1`
--
ALTER TABLE `2_1_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `columnquestion`
--
ALTER TABLE `columnquestion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datasummary`
--
ALTER TABLE `datasummary`
  ADD PRIMARY KEY (`datasummary_id`),
  ADD KEY `part_id` (`part_id`);

--
-- Indexes for table `parttable`
--
ALTER TABLE `parttable`
  ADD PRIMARY KEY (`part_id`),
  ADD KEY `research_topic_id` (`research_topic_id`);

--
-- Indexes for table `sdg2_indicators`
--
ALTER TABLE `sdg2_indicators`
  ADD PRIMARY KEY (`topic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `1_2_3`
--
ALTER TABLE `1_2_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `2_1_1`
--
ALTER TABLE `2_1_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `columnquestion`
--
ALTER TABLE `columnquestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `datasummary`
--
ALTER TABLE `datasummary`
  MODIFY `datasummary_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `datasummary`
--
ALTER TABLE `datasummary`
  ADD CONSTRAINT `datasummary_ibfk_1` FOREIGN KEY (`part_id`) REFERENCES `parttable` (`part_id`);

--
-- Constraints for table `parttable`
--
ALTER TABLE `parttable`
  ADD CONSTRAINT `parttable_ibfk_1` FOREIGN KEY (`research_topic_id`) REFERENCES `sdg2_indicators` (`topic_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
