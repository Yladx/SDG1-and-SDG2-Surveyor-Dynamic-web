<?php include "sdg2_db.php" ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDG2:Zero Hunger</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
    <div style="text-align: right; font-family: Garamond, serif;">
  <i>
    <p style="font-size: 10px; color:rgb(1,1,1,0.6); background-color: rgb(221, 168, 56,0.9);"> | Virtucio | Bondoc| Patricio | Pedroso | - BSIT-2204(2024 @batstate-u lipa) </p>
  </i>
</div>

        <header>
            
            <div class="logo"></div>
            <div class="switch">    
            <div class="header-text">-ZERO HUNGER-</div>
           
                <span class="btn-toggle"></span>
            </div>
            
        </header>
        <main>
            <svg class="toggle-menu" viewBox="0 0 100 100" width="80">
                <path d="m 30,33 h 40 c 0,0 9.044436,-0.654587 9.044436,-8.508902 0,-7.854315 -8.024349,-11.958003 -14.89975,-10.85914 -6.875401,1.098863 -13.637059,4.171617 -13.637059,16.368042 v 40"/>
                <path d="m 30,50 h 40"/>
                <path d="m 30,67 h 40 c 12.796276,0 15.357889,-11.717785 15.357889,-26.851538 0,-15.133752 -4.786586,-27.274118 -16.667516,-27.274118 -11.88093,0 -18.499247,6.994427 -18.435284,17.125656 l 0.252538,40"/>
            </svg>
          
            
            <?php        
        // Include database connection
        include "sdg2_db.php";

        echo '<aside>';  
        echo '<ul class="menu">';  
        echo '<br>';          
        echo '<li>';     
        echo '<div>';
        echo '<span style="color: #e8c37e;"><b> Menu: </b></span>';
        echo '</div>';     
        echo '</li>';

        // "Start" menu item 
        echo '<li>';
        echo '<a href="?menu=start">';
        echo '<div class="main-menu no-submenu" id="startMenuItem">';
        echo '<div>';
        echo '<span>Home</span>';
        echo '</div>';
        echo '</div>';
        echo '</a>';
        echo '</li>';



        // "Answer Survey" menu item with submenu containing all research topics
        echo '<li>';
        echo '<div class="main-menu">';
        echo '<div>';
        echo '<span>Answer Survey</span>';
        echo '</div>';
        echo '<svg class="arrow" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">';
        echo '<path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/>';
        echo '</svg>';
        echo '</div>';
        echo '<ul class="sub-menu">';
       
        
        $researchSql = "SELECT * FROM sdg2_indicators";
        $researchResult = mysqli_query($conn, $researchSql);

        while ($researchRow = mysqli_fetch_assoc($researchResult)) {
            $topic_id = $researchRow['topic_id'];
            $research_topic = $researchRow['research_topic'];
            $submenu_text = "1. {$topic_id} {$research_topic}";
            echo '<li class="sub-menu-item">';
            echo '<div>';
            echo '<span>' . $submenu_text . '</span>';
            echo '</div>';
            echo '<svg class="arrow" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">';
            echo '<path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/>';
            echo '</svg>';

        
            echo '<ul class="sub-sub-menu">';

            // Query to fetch tables with foreign keys referencing the current research topic
            $fkSql = "SELECT p.part_title, p.part_id
                    FROM PartTable p
                    WHERE p.research_topic_id = '$topic_id'";
            
            $fkResult = mysqli_query($conn, $fkSql);
            if ($fkResult && mysqli_num_rows($fkResult) > 0) {
                $part_number = 1; // Initialize the part number
                while ($fkRow = mysqli_fetch_assoc($fkResult)) {
                    $part_title = $fkRow['part_title'];
                    $part_id = $fkRow['part_id'];
                    echo '<li><a href="?part_id=' . $part_id . '&menu=answer_survey">' . '1.' . $topic_id . '.' . $part_number . ' ' . $part_title . '</a></li>';
                    $part_number++;
                }
            } else {
                // Display a message if no parts were found for the current research topic
                echo '<li>No parts found for this topic</li>';
            }

        echo '</ul>';
        echo '</li>';
        }
        echo '</ul>';
        echo '</li>';



        // "Data of Survey" menu item
        echo '<li>';
        echo '<div class="main-menu">';
        echo '<div>';

        echo '<span>Data of Survey</span>';
        echo '</div>';
        echo '<svg class="arrow" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">';
        echo '<path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/>';
        echo '</svg>';
        echo '</div>';
        echo '<ul class="sub-menu">';

        // Query to fetch all research topics from the ResearchTable    
        $researchSql = "SELECT * FROM sdg2_indicators";
        $researchResult = mysqli_query($conn, $researchSql);

        while ($researchRow = mysqli_fetch_assoc($researchResult)) {
            $topic_id = $researchRow['topic_id'];
            $research_topic = $researchRow['research_topic'];
            $submenu_text = "1. {$topic_id} {$research_topic}";
            echo '<li class="sub-menu-item">';
            echo '<div>';
            echo '<span>' . $submenu_text . '</span>';
            echo '</div>';
            echo '<svg class="arrow" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">';
            echo '<path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/>';
            echo '</svg>';

            // Add a sub-submenu for each submenu item containing related tables
            echo '<ul class="sub-sub-menu">';

            // Query to fetch tables with foreign keys referencing the current research topic
            $fkSql = "SELECT p.part_title, p.part_id
                    FROM PartTable p
                    WHERE p.research_topic_id = '$topic_id'";
            
            $fkResult = mysqli_query($conn, $fkSql);

            if ($fkResult && mysqli_num_rows($fkResult) > 0) {
                $part_number = 1; // Initialize the part number
                while ($fkRow = mysqli_fetch_assoc($fkResult)) {
                    $part_title = $fkRow['part_title'];
                    $part_id = $fkRow['part_id'];
                    echo '<li><a href="?part_id=' . $part_id . '&menu=data_of_survey">' . '1.' . $topic_id . '.' . $part_number . ' ' . $part_title . '</a></li>';
                    $part_number++;
                }
            } else {
                // Display a message if no parts were found for the current research topic
                echo '<li>No parts found for this topic</li>';
            }

        echo '</ul>';
        echo '</li>';

        }
        echo '</ul>';
        echo '</li>';
       
        echo '</ul>';
        echo '</aside>';



        if (isset($_GET['part_id']) && isset($_GET['menu']) && strtolower(trim($_GET['menu'])) === 'answer_survey') {
        
           
            $selected_part_id = $_GET['part_id'];

            // Query to fetch the part information based on the selected part ID
            $partInfoSql = "SELECT part_title, part_description, table_ref, partfillup_guide FROM PartTable WHERE part_id = '$selected_part_id'";
            $partInfoResult = mysqli_query($conn, $partInfoSql);

            if ($partInfoRow = mysqli_fetch_assoc($partInfoResult)) {
                $part_title = $partInfoRow['part_title'];
                $part_description = $partInfoRow['part_description'];                
                $table_ref = $partInfoRow['table_ref'];
                $partfillup_guide = $partInfoRow['partfillup_guide'];
                

                
                // Display the part title and description
                echo "<section >";
                echo "<div class='scontainer'>";
                echo "<h1><br>$part_title</h1>";
                echo "<p><br>$part_description<br><br></p>";
                echo '

                <b>Please provide accurate and honest responses to all survey questions to ensure the reliability and usefulness of the collected data. </b><br> <br>';
                
               
              // Query to fetch all column names and data types of the reference table
                $refTableSql = "
                SELECT COLUMN_NAME, DATA_TYPE, COLUMN_TYPE
                FROM information_schema.columns
                WHERE TABLE_SCHEMA = 'sdg2' -- Specify the database name
                AND TABLE_NAME = '$table_ref'
                AND COLUMN_KEY != 'PRI'  -- Exclude primary key
                AND DATA_TYPE != 'TIMESTAMP' -- Exclude columns of type TIMESTAMP
                ";

            

                $refTableResult = mysqli_query($conn, $refTableSql);
            

                if ($refTableResult && mysqli_num_rows($refTableResult) > 0) {
                    echo ' <div class="inner-container">';
                    echo "<i>$partfillup_guide</i> ";
                    echo "<br><br>"; 
                    echo "<form method='post'>";
                    echo "<ul>";
                    while ($row = mysqli_fetch_assoc($refTableResult)) {

                // Fetch column question and direction from ColumnQuestion table based on column name
                $column_name = $row['COLUMN_NAME'];
                $columnQuestionSql = "SELECT column_question, question_direction FROM ColumnQuestion WHERE column_name = '$column_name'";
                $columnQuestionResult = mysqli_query($conn, $columnQuestionSql);
                $columnQuestionRow = mysqli_fetch_assoc($columnQuestionResult);
                
              
                if (!$columnQuestionRow || empty($columnQuestionRow)) {
                    $column_question = $column_name;
                    $question_direction = ""; // No direction available
                } else {
                    $column_question = $columnQuestionRow['column_question'];
                    $question_direction = $columnQuestionRow['question_direction'];
                }

                echo "<li><br>$column_question";
                if (!empty($question_direction)) {
                    echo " <i style='font-style: italic; font-size: 14px;'> ($question_direction)</i>";
                }
                echo "<br>"; 

                        // Display input field based on data type
                        if ($row['DATA_TYPE'] == 'int' || $row['DATA_TYPE'] == 'varchar' || $row['DATA_TYPE'] == 'text' || $row['DATA_TYPE'] == 'decimal'||$row['DATA_TYPE'] == 'year' ) {
                            if ($row['COLUMN_NAME'] == 'PPA_description') {
                                echo "<textarea name='" . $row['COLUMN_NAME'] . "' rows='4' cols='50'></textarea>";
                            } else {
                                echo "<input type='text' name='" . $row['COLUMN_NAME'] . "' value=''>";
                            }
                        } elseif ($row['DATA_TYPE'] == 'tinyint') {
                            echo "<input type='radio' name='" . $row['COLUMN_NAME'] . "' value='1' >Yes ";
                            echo "<input type='radio' name='" . $row['COLUMN_NAME'] . "' value='0'> No ";
                        }elseif ($row['DATA_TYPE'] == 'enum') {
                        // Extract enum values
                    preg_match_all("/'(.*?)'/", $row['COLUMN_TYPE'], $matches);
                    $enum_values = $matches[1];

                    // Display enum values as radio buttons
                    foreach ($enum_values as $enum_value) {
                        echo "<input type='radio' name='$column_name' value='$enum_value'>$enum_value <br>";
                    }
                        }
                    
                        echo "</li>";
                    }
                    echo "</ul><br>";
                   
                    echo '</div><br>';
              
                    
                    echo "<script>
                    function calculatePercentage() {
                        var form = document.querySelector('form');
                        var inputs = form.querySelectorAll('input[type=text], textarea, input[type=radio]:checked');
                        var totalFields = inputs.length;
                        var filledFields = 0;
                
                        inputs.forEach(function(input) {
                            if (input.type === 'radio') {
                                var radioGroup = form.querySelectorAll('input[type=radio][name=' + input.name + ']');
                                if (Array.from(radioGroup).some(radio => radio.checked)) {
                                    filledFields++;
                                }
                            } else {
                                if (input.value !== '') {
                                    filledFields++;
                                }
                            }
                        });
                
                        var percentage = (filledFields / totalFields) * 100;
                        document.getElementById('filledPercentage').innerText = 'Completion: ' + percentage.toFixed(2) + '%';
                    }
                
                    document.addEventListener('DOMContentLoaded', function() {
                        calculatePercentage(); // Calculate initial percentage on page load
                
                        var inputs = document.querySelectorAll('input, textarea');
                        inputs.forEach(function(input) {
                            input.addEventListener('input', calculatePercentage); // Recalculate percentage on input change
                        });
                    });
                </script>";
                
                
                
                
              // Display the percentage calculation result within the styled box
        echo "<div class='percentage' id='filledPercentage'></div>";
                
                // Modify form submission validation
                echo "<input type='submit' class='submit-button' value='Submit' onclick='return validateForm();'>";
                
                // JavaScript function to validate the form based on the percentage of filled fields
                echo "<script>
                    function validateForm() {
                        var percentage = parseFloat(document.getElementById('filledPercentage').innerText.split(':')[1].trim());
                        if (percentage < 100) {
                            alert('Please fill in all fields before submitting.');
                            return false; // Prevent form submission
                        }
                        return true; // Allow form submission if all fields are filled
                    }
                </script>";
                
                    echo "</form>";
        
        
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
          
                        $insertQuery = "INSERT INTO $table_ref (";
                        $values = [];
                    
                        
                    
                        foreach ($_POST as $key => $value) {
                            
                            if ($key !== 'submit') {
                              
                                if (is_array($value)) {
                                    $cleaned_value = mysqli_real_escape_string($conn, $value[0]);
                                } else {
                                    $cleaned_value = mysqli_real_escape_string($conn, $value);
                                }
                                
                                if(empty($cleaned_value)){ // Check if field is empty
                                    $fields_filled = false;
                                    break; // Exit loop if any field is empty
                                }
                                
                                $insertQuery .= "`$key`, ";
                                $values[] = "'$cleaned_value'";
                            }
                        }
                   
                      
                        $insertQuery = rtrim($insertQuery, ", ");
                        $insertQuery .= ") VALUES (";
                        $insertQuery .= implode(', ', $values);
                        $insertQuery .= ")";
                    
                        // Execute the INSERT statement
                        if (mysqli_query($conn, $insertQuery)) {
                            echo "<script>alert('Thank you For Answering this Survey. Your Form has been recorded successfully.'); window.location = 'sdg2home.php?menu=start';</script>";
                         
                        } else {
                            echo "Error: " . $insertQuery . "<br>" . mysqli_error($conn);
                             // Refresh the page after submit
                            echo "<script>window.location = window.location.href;</script>";
                        }
                    }
                    
                }
                echo '<br><br> <br>';
                echo "</div>";
                echo "</section>";
            } else {
                echo "<section>";
                echo "<div class='scontainer'>";
                // Handle case when no part is found
                echo "No part found for the selected ID.";

                echo "</div>";
                echo "</section>";
            }
        }


    


        //This row for getting the Data per survey
        elseif (isset($_GET['part_id']) && isset($_GET['menu']) && strtolower(trim($_GET['menu'])) === 'data_of_survey') {
            // Get the selected part ID
            $selected_part_id = $_GET['part_id'];

            // Query to fetch the part information based on the selected part ID
            $partInfoSql = "SELECT part_title, part_description, table_ref FROM PartTable WHERE part_id = '$selected_part_id'";
            $partInfoResult = mysqli_query($conn, $partInfoSql);

          
            echo '<section>';

            // Display the fetched part information
            if (mysqli_num_rows($partInfoResult) > 0) {
                $partRow = mysqli_fetch_assoc($partInfoResult);
                $table_ref = $partRow['table_ref'];

                
        // Display the fetched part information
        echo '<h2><br><br> Data Summary of ' . $partRow['part_title'] . '</h2> <br>';
                // Display the data summary from the datasummary table
                echo ' <div class="inner-container">';
                echo 'Reminder: This Data Was Only Based on the Inserted Data in the Database <br>';
                echo '</div>';
                $dataSummarySql = "SELECT datasummary_description, data_query FROM datasummary WHERE part_id = '$selected_part_id'";
                $dataSummaryResult = mysqli_query($conn, $dataSummarySql);
                        
                // Check if there are any data summaries for the selected part
        if(mysqli_num_rows($dataSummaryResult) > 0) {
            // Loop through each data summary
            while ($dataSummaryRow = mysqli_fetch_assoc($dataSummaryResult)) {
                echo '<br><p><i>' . $dataSummaryRow['datasummary_description'] . '</i></p><br>';

                // Execute the data query to fetch the table
                $dataQuery = $dataSummaryRow['data_query'];
                $tableDataResult = mysqli_query($conn, $dataQuery);

                if ($tableDataResult) {
                    // Display the table
                    if (mysqli_num_rows($tableDataResult) > 0) {
                        echo '<table border="1">'; 
                        
                        echo '<tr>';
                        while ($columnInfo = mysqli_fetch_field($tableDataResult)) {
                            echo '<td><b>' . $columnInfo->name . '</b></td>';
                        }
                        echo '</tr>';

                        // Display data rows
                        while ($row = mysqli_fetch_assoc($tableDataResult)) {
                            echo '<tr>';
                            foreach ($row as $columnValue) {
                                echo '<td><p>' . $columnValue . '</p></td>';
                            }
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo '<p>No data available.</p>';
                    }
                } else {
                    echo '<p>Error executing the data.</p>';
                }
            }
        } else {
            echo '<p>No data or table yet for this part.</p>';
        }
                    
                echo '<br><br>';
                
                echo '<button id="viewTableBtn">View Table Data</button>';

                echo ' <div class="data-table-container ">';

                // Query to fetch data from the reference table
                $refTableDataSql = "SELECT * FROM $table_ref"; // Assuming $table_ref contains the name of the reference table
                $refTableDataResult = mysqli_query($conn, $refTableDataSql);

                // Display the data from the reference table
                if ($refTableDataResult && mysqli_num_rows($refTableDataResult) > 0) {
                
                   if(isset($_POST['delete']) && isset($_POST['id'])) {
                         //Get the row ID to be deleted
                       $delete_id = $_POST['id'];
                        
                        // Query to delete the row from the reference table
                       $deleteRowSql = "DELETE FROM $table_ref WHERE id = $delete_id"; // Assuming 'id' is the primary key
                       if(mysqli_query($conn, $deleteRowSql)) {
                            echo '<script>alert("Row deleted successfully."); </script>';

                            // Reload the page after deletion
            echo '<meta http-equiv="refresh" content="0">';
                            exit; // Stop further execution
                       } else {
                           echo '<p>Error deleting row: ' . mysqli_error($conn) . '</p>';
                            exit;
                        }
                   }
                    
                // echo '<p><br>This is the Tabke of '. $partRow['part_title'] . '. <br></p>';

                echo '<br><br><br><br>';
                    echo '<table border="1">';
                  
                    echo '<tr>';
                    while ($columnInfo = mysqli_fetch_field($refTableDataResult)) {
                        echo '<td><b>' . $columnInfo->name . '</b></td>';
                    }
                    echo '</tr>';
                    
                    while ($row = mysqli_fetch_assoc($refTableDataResult)) {
                        echo '<tr>';
                        foreach ($row as $columnValue) {
                            echo '<td><p>' . $columnValue . '</p></td>';
                        }
                        echo '<td>';
                        echo '<form method="post">';
                        echo '<input type="hidden" name="id" value="' . $row['id'] . '">';

                         echo '<input type="submit" name="delete" value="Delete" class="delete-button">';

                        echo '</form>';
                        echo '</td>'; 
                        echo '</tr>';
                        
                    }
                    echo '</table>';
                    echo '<br><br><br><br>';
                } else {
                    echo '<p>No data available in the reference table.</p>';
                }
            } else {
                echo '<p>No part information found for the selected part ID.</p>';
            }
       
            echo '</div>';
        
            echo '</section>';
        }
    
        
 else {

            echo '<section>';
            echo '<div class="scontainer">';

            echo '<br><br><h1>Sdg 2: Zero Hunger</h1>';
            echo '<p><br>Sustainable Development Goal 2 (SDG 2), "Zero Hunger," aims to eradicate hunger, achieve food security, improve nutrition, and promote sustainable agriculture by 2030. It addresses the right to access safe, nutritious food, emphasizing collaborative efforts across local, national, and global levels. SDG 2 focuses on enhancing agricultural productivity, equitable food distribution, and sustainable practices while tackling root causes like poverty and climate change. Data-driven approaches and collaboration are vital for tracking progress and implementing effective interventions, ensuring a future where no one goes hungry and food systems are resilient and sustainable.</p>';

            // Fetch research topics from the database
            $researchSql = "SELECT * FROM sdg2_indicators";
            $researchResult = mysqli_query($conn, $researchSql);
            // Check if there are any results
            if (mysqli_num_rows($researchResult) > 0) {
                while ($row = mysqli_fetch_assoc($researchResult)) {
                    
                    // Display research topic
                    echo '<br><h3>' . $row['research_topic'] . '</h3><br>';
                    echo '<div class="button-container">';

                    // Fetch parts for the current research topic
                    $topic_id = $row['topic_id'];
                    $fkSql = "SELECT p.part_title, p.part_id, p.table_ref
                            FROM PartTable p
                            WHERE p.research_topic_id = '$topic_id'";
                    $fkResult = mysqli_query($conn, $fkSql);

                    
                    if (mysqli_num_rows($fkResult) > 0) {
                        
                        while ($partRow = mysqli_fetch_assoc($fkResult)) {
                            echo '<div class="button-with-text">';
                            
                            // Generate the image URL based on the table reference and image location
                            $imageURL = 'Resorces/Icon/' . $partRow['table_ref'] . '.png';
                            echo '<a href="?part_id=' . $partRow['part_id'] . '&menu=answer_survey" class="answer-part-box-button" style="background-image: url(\'' . $imageURL . '\');">';
                            echo '</a>';
                            echo '<p class="button-text">' . $partRow['part_title'] . '</p>';
                            
                            echo '</div>';
                        }
                    } else {
                        echo '<br><br><p>No parts found for this topic</p> <br>';
                    }

                    echo '</div>';
                }
            } else {
                
                echo '<br><br><h3>No research topics found</h3>';
            }

            echo '<br><br></div>';
            echo '</section>';
        }



        ?>         
            </main>      
            </div>    
        <script src="script.js"></script>
        </body>
        </html>