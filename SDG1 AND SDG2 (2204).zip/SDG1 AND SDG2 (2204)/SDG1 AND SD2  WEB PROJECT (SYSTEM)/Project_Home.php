<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div style="text-align: right; font-family: Garamond, serif;">
  <i>
    <p style="font-size: 10px; color:rgb(1,1,1,0.6); background-color: #333333;"> | Virtucio | Bondoc| Patricio | Pedroso | - BSIT-2204(2024 @batstate-u lipa) </p>
  </i>
</div>
<header>
    <div class="header-text">Sustainable Development Goals</div>
    <span class="btn-toggle"></span>
</header>
<section style="background-image: url(sdgvg.jpg)">
    <br>
    <br>
   <p style="color:white; font-size: 2.5vh;">The Sustainable Development Goals (SDGs) are a collection of 17 global goals set by the United Nations in 2015 as part of the 2030 Agenda for Sustainable Development. These goals are designed to address a wide range of global challenges, including poverty, inequality, climate change, environmental degradation, peace, and justice. Each goal has specific targets and indicators to measure progress.</p>
    <div class="button-container">
        <div class="button-with-text">
            <button class="button button1" style="background-image: url(SDG1.png);" data-description="
            SDG 1: No Poverty aims to eradicate all forms of extreme poverty globally, ensuring equal access to economic resources and social protection systems." onclick="openUrl('SDG1/sdg1home.php')"></button>
            <p class="description">SDG 1 No Poverty</p>
        </div>
        <div class="button-with-text">
            <button class="button button2"style="background-image: url(SDG2.png);"  data-description="SDG 2: Zero Hunger seeks to end hunger, achieve food security, improve nutrition, and promote sustainable agriculture worldwide." onclick="openUrl('Sdg2/sdg2home.php')"></button>
            <p class="description">SDG 2: Zero Hunger</p>
        </div>
    </div>
</section>




<script>
    function openUrl(url) {
        window.location.href = url;
    }
</script>
<footer>
  <p>&copy; 2024 All right reserved (Batstate-u-TNEU-lipa)</p>
  </footer>
</body>

</html>