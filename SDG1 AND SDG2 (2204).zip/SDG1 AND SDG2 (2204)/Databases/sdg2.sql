-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2024 at 08:34 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sdg2`
--

-- --------------------------------------------------------

--
-- Table structure for table `2_1_1`
--

CREATE TABLE `2_1_1` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `year_of_publication` int(4) DEFAULT NULL,
  `total_citations` int(11) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `2_1_1`
--

INSERT INTO `2_1_1` (`id`, `title`, `author`, `year_of_publication`, `total_citations`, `Survey_datetimestamp`) VALUES
(6, 'asd', 'asd', 0, 0, '2024-05-17 15:54:48');

-- --------------------------------------------------------

--
-- Table structure for table `2_2`
--

CREATE TABLE `2_2` (
  `id` int(6) UNSIGNED NOT NULL,
  `year` year(4) NOT NULL,
  `month` enum('January','February','March','April','May','June','July','August','September','October','November','December') NOT NULL,
  `food_waste` decimal(10,2) NOT NULL,
  `population` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `2_3_1`
--

CREATE TABLE `2_3_1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `srcode` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `section` varchar(255) DEFAULT NULL,
  `experienced_hunger` tinyint(1) DEFAULT NULL,
  `hunger_frequency` enum('Rarely','Sometimes','Often','Very often') DEFAULT NULL,
  `experienced_weight_loss` tinyint(1) DEFAULT NULL,
  `weight_loss_amount` varchar(50) DEFAULT NULL,
  `sought_medical_support` tinyint(1) DEFAULT NULL,
  `impact_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `2_3_1`
--

INSERT INTO `2_3_1` (`id`, `name`, `srcode`, `gender`, `age`, `section`, `experienced_hunger`, `hunger_frequency`, `experienced_weight_loss`, `weight_loss_amount`, `sought_medical_support`, `impact_description`) VALUES
(2, 'a', 'a', 'Male', '12', 'asd', 1, 'Sometimes', 1, '123', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `2_3_2`
--

CREATE TABLE `2_3_2` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `2_3_2`
--

INSERT INTO `2_3_2` (`id`, `PPA_title`, `PPA_description`, `PPA_COST`, `PPA_fundsource`, `Survey_datetimestamp`) VALUES
(1, 'a', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa sa dsad as astanginaam oajk odasj opasjfioashfiuashfijas hfiau aishf uiasohf iouashf\r\nfasifhasifhasiuofas', 213.00, '213', '2024-04-29 18:29:22'),
(2, 'asd', 'sadddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', 0.00, 'a', '2024-05-02 08:54:08'),
(3, 'as', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadd', 0.00, 'sad', '2024-05-02 09:03:04');

-- --------------------------------------------------------

--
-- Table structure for table `2_3_3`
--

CREATE TABLE `2_3_3` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `staff_position` varchar(255) DEFAULT NULL,
  `experienced_hunger` tinyint(1) DEFAULT NULL,
  `hunger_frequency` enum('Rarely','Sometimes','Often','Very often') DEFAULT NULL,
  `experienced_weight_loss` tinyint(1) DEFAULT NULL,
  `weight_loss_amount` varchar(50) DEFAULT NULL,
  `sought_medical_support` tinyint(1) DEFAULT NULL,
  `impact_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `2_3_3`
--

INSERT INTO `2_3_3` (`id`, `name`, `gender`, `age`, `staff_position`, `experienced_hunger`, `hunger_frequency`, `experienced_weight_loss`, `weight_loss_amount`, `sought_medical_support`, `impact_description`) VALUES
(0, 'asd', 'Male', 'asd', 'asd', NULL, 'Sometimes', 1, 'asd', 1, 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `2_3_4`
--

CREATE TABLE `2_3_4` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `2_3_5`
--

CREATE TABLE `2_3_5` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `2_4_1`
--

CREATE TABLE `2_4_1` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `2_4_2`
--

CREATE TABLE `2_4_2` (
  `id` int(11) NOT NULL,
  `PPA_title` varchar(255) DEFAULT NULL,
  `PPA_description` text DEFAULT NULL,
  `PPA_COST` decimal(10,2) DEFAULT NULL,
  `PPA_fundsource` varchar(100) DEFAULT NULL,
  `Survey_datetimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `2_4_3`
--

CREATE TABLE `2_4_3` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `accessed_facilities` text DEFAULT NULL,
  `learning_source` enum('University outreach programs','Local agricultural organizations','Word of mouth','Other') DEFAULT NULL,
  `resources_support` enum('Access to equipment and machinery','Training workshops or seminars','Research collaboration','Technical assistance from faculty or staff','Financial support or grants','Other') DEFAULT NULL,
  `benefits` text DEFAULT NULL,
  `challenges` text DEFAULT NULL,
  `recommend` tinyint(1) DEFAULT NULL,
  `suggestions` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `columnquestion`
--

CREATE TABLE `columnquestion` (
  `id` int(11) NOT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `column_question` varchar(255) DEFAULT NULL,
  `question_direction` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `columnquestion`
--

INSERT INTO `columnquestion` (`id`, `column_name`, `column_question`, `question_direction`) VALUES
(1, 'title', 'Title: ', 'Title of the research'),
(2, 'author', 'Author: ', 'Author of the Research'),
(3, 'year_of_publication', 'Year of Publication: ', 'Format: YYYY'),
(4, 'total_citations', 'Total Citations: ', ''),
(5, 'Name', 'Name: ', '(for now optional to put name)'),
(6, 'Year', 'Year: ', NULL),
(7, 'gender', ' Gender: ', NULL),
(8, 'TuitionAssistance', 'Do you Recieve any TuitionAssistance?', NULL),
(9, 'PrivateScholarship', 'If you are receiving tuition assistance/school financial aid, is it private funded financial aid/scholarship?', NULL),
(10, 'GovtScholarship', 'If you are receiving tuition assistance/school financial aid, is it provided by the government as a scholarship?', NULL),
(11, 'OtherScholarship', 'Do you Receive other Scholarship Aside From those two?', NULL),
(12, 'LowIncomeFamily', 'Do you consider your household to be low-income', NULL),
(13, 'FamilyMemberOf4Ps', 'Do you any have any family Members that member of 4P\'s?', NULL),
(14, 'book_vouchers', 'Have you received book vouchers to assist with your educational expenses?', NULL),
(15, 'computer_vouchers', 'Have you received vouchers to purchase computers or related equipment for your studies?', NULL),
(17, 'school_supplies_vouchers ', 'Have you received vouchers to obtain school supplies such as stationery, textbooks, or other educational materials?', NULL),
(18, 'PPA_title', 'Title of the PPA:', 'Name of the program/initiative.'),
(19, 'PPA_description', 'Short description:', 'Brief overview of the program\'s objectives and key features.'),
(20, 'PPA_COST', 'Total cost:', 'Total budget allocated for the program.'),
(21, 'PPA_fundsource', 'Fund source:', 'Source(s) of funding for the program.'),
(22, 'country_income', 'What do you perceive as the income level of co-authored country?', NULL),
(23, 'co-authored_country', 'Which country or countries was collaborate or co-authored with the research?', NULL),
(25, 'YearGraduated', 'Year Graduated:', 'format: YYYY '),
(26, 'Course_Taken', 'Course:', NULL),
(27, 'Is_Employed', 'Are you currently employed while studying?', NULL),
(28, 'Employment_Working_Hours', 'Employment Working Hours: ', 'Number of Working Hours per Week'),
(30, 'Employment_Length_of_Service', 'Length of Service:', 'in months'),
(31, 'Is_Student_Assistant', 'Are you a student assistant on campus?', NULL),
(32, 'SA_Length_of_Service', 'Length of Service:', 'in months'),
(33, 'Employment_Work_Type', 'Type of Work:', 'like: cashier, clerk, etc'),
(34, 'Employment_Work_Place', 'Workplace Name:', NULL),
(35, 'Total_Assistance_Amount', 'Please specify the total amount of financial assistance provided to your start-up:', NULL),
(36, 'Startup_Name', 'Would you be willing to share the name of your start-up that received financial assistance? ', 'Optional'),
(37, ' Financial_Assistance_Source', 'If yes, please specify the source of the financial assistance:', NULL),
(38, 'Received_Financial_Assistance ', 'Did your start-up receive financial assistance for its establishment?', NULL),
(39, 'IsForeignStudent ', 'Are you a foreign student at our campus?', NULL),
(40, 'SatisfactionLevel', 'What would you Rate Your Satisfaction on our Campus/Univerities?', NULL),
(41, 'WouldRecommend', 'Would you recommend our campus/Universirty to other students from your home countries?', NULL),
(42, 'FinancialSupportfromcampus', 'Are You Receiving Financial Support from our University/Campus?', NULL),
(43, 'fromlowincomecountry', 'Do you consider your home country to be from a low-income background?', NULL),
(44, 'SrCode', 'SR-CODE: ', NULL),
(45, 'Section', 'Section:', NULL),
(46, 'age', 'Age:', NULL),
(47, 'experienced_hunger', 'Have you experienced hunger in the last 12 months due to lack of access to food?', NULL),
(48, 'hunger_frequency', 'If yes, how often did you experience hunger?', 'Rarely (1-2 times),\r\nSometimes (3-5 times),\r\nOften (6-10 times),\r\nVery often (more than 10 times),'),
(49, 'experienced_weight_loss', 'Have you ever experienced weight loss as a result of financial hardship or poverty?', NULL),
(50, 'weight_loss_amount', 'If yes, approximately how much weight did you lose?', 'in pounds or kilograms'),
(51, 'sought_medical_support\r\n', 'Have you sought medical support due to experiencing hunger or losing weight?', NULL),
(52, 'impact_description', 'How would you describe the impact of hunger on your academic performance and overall well-being?in the last 12 months due to poverty or lack of access to nutritious food?', NULL),
(53, 'staff_position', 'What your working position?\r\n', 'like instructor, guard, janitor etc'),
(54, 'learning_source', 'How did you learn about the opportunity to access university facilities for sustainable farming practices?', NULL),
(55, 'accessed_facilities', 'Specify the university facilities you have accessed for sustainable farming practices. ', 'List all facilities eg. Technology laboratories\r\nGreenhouses,Experimental fields, Research farms etc'),
(56, 'resources_support', 'What specific resources or support did you receive from the university to enhance your farming practices?', NULL),
(57, 'benefits', 'How has access to university facilities benefited your farming or production practices?', NULL),
(58, 'challenges', 'Have you faced any challenges or barriers in accessing university facilities for sustainable farming practices? If yes, please describe.', NULL),
(59, 'recommend', 'Would you recommend other local farmers or producers to utilize university facilities for improving sustainable farming practices? Why or why not?', NULL),
(60, 'suggestions', 'Do you have any suggestions for how the university can further support local farmers and producers in accessing facilities for sustainable farming practices?', NULL),
(61, 'population', 'Total Campus Population:', NULL),
(62, 'food_waste', 'Total food waste on campus:', 'in kg may have decimals'),
(63, 'month', 'Month:', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `datasummary`
--

CREATE TABLE `datasummary` (
  `datasummary_id` int(11) NOT NULL,
  `datasummary_description` text DEFAULT NULL,
  `data_query` text DEFAULT NULL,
  `part_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datasummary`
--

INSERT INTO `datasummary` (`datasummary_id`, `datasummary_description`, `data_query`, `part_id`) VALUES
(1, 'Total number of long-term programme in place on student food\r\ninsecurity:', 'SELECT COUNT(*) AS ppa_count FROM 2_3_2;', 5),
(2, 'Students and staff hunger interventions', 'SELECT COUNT(*) AS ppa_count FROM 2_3_4;', 7),
(3, 'Total number of PPAs for sustainable food choices:', 'SELECT COUNT(*) AS ppa_count FROM 2_3_5;', 8),
(4, 'Total number of extension activities that provide food security\r\nknowledge:', 'SELECT COUNT(*) AS ppa_count FROM 2_4_1;', 9),
(5, 'Total number of events provided:', 'SELECT COUNT(*) AS ppa_count FROM 2_4_2;', 10),
(6, 'Total number of published research on hunger:', 'SELECT COUNT(*) AS NumberOfResearch\r\nFROM 2_1_1;', 1),
(7, 'A total  number and percentage of students (m/f) from the\ncampus experience hunger in the last 12 months:', 'SELECT \r\n    IFNULL(gender, \'Total\') AS gender,\r\n    COUNT(*) AS total_students_Experience_hunger\r\nFROM \r\n    `2_3_1`\r\nWHERE \r\n    experienced_hunger = 1\r\nGROUP BY \r\n    gender\r\nWITH ROLLUP\r\n\r\nUNION ALL\r\n\r\nSELECT \r\n    \'Percentage\' AS gender,\r\n    IFNULL(CAST(COUNT(*) / (SELECT COUNT(*) FROM `2_3_1` WHERE experienced_hunger = 1) * 100 AS DECIMAL(5,2)), 0) AS total_percentage\r\nFROM \r\n    `2_3_1`\r\nWHERE \r\n    experienced_hunger = 1;\r\n', 4),
(8, 'A total  number and percentage of students (m/f) from the\ncampus lose weight in the last 12 months:', 'SELECT \r\n    IFNULL(gender, \'Total\') AS gender,\r\n    COUNT(*) AS total_students__Experience_weightloss\r\nFROM \r\n    `2_3_1`\r\nWHERE \r\n    experienced_weight_loss = 1\r\nGROUP BY \r\n    gender\r\nWITH ROLLUP\r\n\r\nUNION ALL\r\n\r\nSELECT \r\n    \'Percentage\' AS gender,\r\n    IFNULL(CAST(COUNT(*) / (SELECT COUNT(*) FROM `2_3_1` WHERE experienced_weight_loss = 1) * 100 AS DECIMAL(5,2)), 0) AS total_percentage\r\nFROM \r\n    `2_3_1`\r\nWHERE \r\n    experienced_weight_loss = 1;\r\n', 4),
(9, 'A total number and percentage of employees (m/f) from the campus experience hunger in the last 12 months:', 'SELECT \r\n    IFNULL(gender, \'Total\') AS gender,\r\n    COUNT(*) AS total_employees_Experience_hunger\r\nFROM \r\n    `2_3_3`\r\nWHERE \r\n    experienced_hunger = 1\r\nGROUP BY \r\n    gender\r\nWITH ROLLUP\r\n\r\nUNION ALL\r\n\r\nSELECT \r\n    \'Percentage\' AS gender,\r\n    IFNULL(CAST(COUNT(*) / (SELECT COUNT(*) FROM `2_3_3` WHERE experienced_hunger = 1) * 100 AS DECIMAL(5,2)), 0) AS total_percentage\r\nFROM \r\n    `2_3_3`\r\nWHERE \r\n    experienced_hunger = 1;\r\n', 6),
(10, 'A total number and percentage of employees (m/f) from the campus lose weight in the last 12 months due to poverty:', 'SELECT \r\n    IFNULL(gender, \'Total\') AS gender,\r\n    COUNT(*) AS total_employees\r\nFROM \r\n    `2_3_3`\r\nWHERE \r\n    experienced_weight_loss = 1\r\nGROUP BY \r\n    gender\r\nWITH ROLLUP\r\n\r\nUNION ALL\r\n\r\nSELECT \r\n    \'Percentage\' AS gender,\r\n    IFNULL(CAST(COUNT(*) / (SELECT COUNT(*) FROM `2_3_3` WHERE experienced_weight_loss = 1) * 100 AS DECIMAL(5,2)), 0) AS total_percentage\r\nFROM \r\n    `2_3_3`\r\nWHERE \r\n    experienced_weight_loss = 1;\r\n', 6),
(11, 'Total number of local farmers and producers who were given access\r\nto university facilities: (male/female)', 'SELECT \n    gender,\n    COUNT(*) AS total_count\nFROM \n    2_4_3\nGROUP BY \n    gender\n\nUNION ALL\n\nSELECT \n    \'Total\' AS gender,\n    COUNT(*) AS total_count\nFROM \n    2_4_3\n\n', 11),
(12, 'Top 10 records with the highest foodwastes:', 'SELECT *\r\nFROM `2_2`\r\nORDER BY `food_waste` DESC\r\nLIMIT 10', 2),
(13, '\r\nAverage Foodwaste per year and population:', 'SELECT \r\n    `year`, \r\n    AVG(`food_waste`) AS avg_food_waste,\r\n    AVG(`population`) AS avg_population\r\nFROM \r\n    `2_2`\r\nGROUP BY \r\n    `year`;\r\n', 2),
(14, 'Food waste per capita (month):', 'SELECT \r\n    `year`, \r\n    `month`,\r\n    SUM(`food_waste`) / SUM(`population`) AS food_waste_per_capita\r\nFROM \r\n    `2_2`\r\nGROUP BY \r\n    `year`, \r\n    `month`\r\nORDER BY \r\n    `year`, \r\n    FIELD(`month`, \'January\', \'February\', \'March\', \'April\', \'May\', \'June\', \'July\', \'August\', \'September\', \'October\', \'November\', \'December\');\r\n\r\n', 2),
(15, 'Food waste per capita (annum):', 'SELECT \r\n    `year`, \r\n    SUM(`food_waste`) / SUM(`population`) AS food_waste_per_capita\r\nFROM \r\n    `2_2`\r\nGROUP BY \r\n    `year`;', 2);

-- --------------------------------------------------------

--
-- Table structure for table `parttable`
--

CREATE TABLE `parttable` (
  `part_id` int(11) NOT NULL,
  `part_title` varchar(255) DEFAULT NULL,
  `research_topic_id` int(11) DEFAULT NULL,
  `table_ref` varchar(255) DEFAULT NULL,
  `part_description` text DEFAULT NULL,
  `partfillup_guide` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parttable`
--

INSERT INTO `parttable` (`part_id`, `part_title`, `research_topic_id`, `table_ref`, `part_description`, `partfillup_guide`) VALUES
(1, 'Research on hunger', 1, '2_1_1', 'The section on research on hunger delves into critical areas such as the impact of land-use change on food security, the relationship between food waste and hunger, and the effectiveness of school feeding programs. Researchers in these fields explore the complexities surrounding food insecurity, aiming to uncover insights that inform effective interventions and policies. They investigate how changes in land use affect food production and security, analyze the connection between food waste and hunger to develop solutions for reducing waste and increasing food access, and assess the effectiveness of school feeding programs in improving children\'s nutritional status and educational outcomes. By addressing these interconnected challenges, researchers seek to advance understanding and promote evidence-based strategies to combat hunger and foster sustainable food systems.', 'This form gathers information related to research on Hunger. Please provide details about the research study, including its title, author(s), year of publication, and total citations. Your accurate responses are essential for reliable data collection.'),
(2, 'Total campus food  waste & Food waste per capita', 2, '2_2', '\nThe section \"2.2.1 Total campus food waste\" provides a comprehensive overview of the quantity of food discarded or lost uneaten across all catering services on the campus. This data is crucial for understanding the scale of food waste generated within the campus environment and for identifying opportunities to implement strategies for waste reduction and management effectively.<br><br>\n\nBy quantifying the total food waste generated on campus over a specified period, this section sheds light on the magnitude of the issue and highlights the need for proactive measures to address it. The provided breakdown of monthly food waste quantities offers insight into potential trends or variations in waste generation throughout the year, which can inform targeted interventions and initiatives.<br><br>\n\nAdditionally, the comparison of food waste data against the campus population helps contextualize the scale of waste relative to the size of the campus community. This comparison can facilitate benchmarking efforts and support the development of waste reduction targets that are tailored to the specific needs and characteristics of the campus environment.<br><br>\n\nMoving on to \"2.2.2 Food waste per capita,\" this metric calculates the average amount of food waste generated per person within the campus community. By quantifying food waste on a per capita basis, this section provides a standardized measure that allows for meaningful comparisons across different time periods or demographic groups.', 'Instructions for authorized personnel filling out section 2.2.1: Enter the year and monthly food waste in kilograms. Calculate the annual total and record the campus population accurately. Review for precision before submission to ensure data integrity.'),
(4, 'Proportion of students who experience hunger', 3, '2_3_1', 'In recent years, concerns about food insecurity and poverty among university students have gained significant attention. The academic environment, often perceived as a hub of learning and growth, is not immune to the challenges faced by broader society. Within this context, understanding the prevalence and impact of hunger and poverty-related issues among students is crucial for devising effective interventions and support systems.\n\nThis section examines the prevalence of hunger and weight loss among students at our campus over the past 12 months. Despite being centers of higher education and innovation, campuses worldwide are witnessing a concerning trend: a notable portion of students experiencing food insecurity and its associated consequences. While the inserted data provides specific statistics for our campus, it is part of a broader narrative unfolding across educational institutions globally.\n\nBy delving into the realities faced by our student population, we aim to shed light on the multifaceted challenges they encounter beyond academic pursuits. Through this examination, we seek to initiate a dialogue on how to address these challenges comprehensively, fostering an environment where every student has equitable access to basic necessities and can thrive academically and personally.', 'The survey focuses on hunger and poverty among students exclusively at our campus, aiming to understand the extent and impact of food insecurity over the past year. By collecting honest responses, we aim to uncover how financial constraints affect academic performance and well-being. This data will guide efforts to address these challenges, ensuring all students have equal access to essential resources for academic and personal success.'),
(5, 'Student food insecurity and hunger', 3, '2_3_2', 'In section 2.3.2, there are currently no long-term programs in place specifically addressing student food insecurity. This highlights an area where institutions could potentially develop initiatives to provide sustained support for students facing food insecurity challenges. Long-term programs could include strategies such as establishing food assistance programs, implementing financial aid initiatives, or offering ongoing support services to address the root causes of food insecurity among students. By implementing such programs, institutions can better support the well-being and success of their student population.', 'To address student food insecurity and hunger over the long term, institutions may implement initiatives such as sustainable meal assistance programs, financial aid packages, or community partnerships, with detailed titles, descriptions, and cost estimates provided for each program.'),
(6, 'Proportion of employees who experience hunger', 3, '2_3_3', 'This section provides insights into the prevalence of hunger and weight loss among employees at the campus over the past year, specifically attributed to poverty. It aims to gauge the extent of food insecurity within the employee population and its associated impacts. By examining these factors, organizations can better understand the challenges their employees face and develop strategies to support their well-being. Additionally, tracking these metrics enables institutions to assess the effectiveness of existing support systems or identify areas for improvement in addressing poverty-related issues among their workforce.', 'This survey exclusively targets employees of our campus, aiming to comprehend the prevalence and consequences of food insecurity over the past year. By gathering candid responses, our goal is to unveil the influence of financial constraints on overall well-being. This data will inform strategies to mitigate these challenges, guaranteeing equitable access to vital resources for personal and professional advancement.'),
(7, 'Students and staff hunger interventions', 3, '2_3_4', 'In section 2.3.4, there are currently no implemented interventions to address hunger among students and staff. This indicates a need to develop strategies to alleviate food insecurity within the community. Potential interventions may include establishing food banks or pantries to provide access to nutritious meals, implementing meal subsidy programs, or offering cooking classes and nutritional education workshops. By acknowledging and tackling food insecurity among students and staff, organizations can foster a supportive environment that prioritizes the well-being and success of all members.', 'To address hunger among students and staff, establish a sustainable, long-term intervention such as a food assistance program, providing access to food banks/pantries, with a clear title, description, and cost breakdown.'),
(8, 'Sustainable, healthy and affordable food choices on campus', 3, '2_3_5', 'Under section 2.3.5, there is currently no available information regarding specific Program and Project Activities (PPAs) aimed at providing sustainable, healthy, and affordable food choices on campus. This suggests a potential area for development in ensuring that all members of the campus community have access to nutritious and environmentally-friendly food options, including vegetarian and vegan choices. Potential PPAs may involve initiatives such as sourcing locally grown produce, offering discounted meal plans for students, or partnering with sustainable food vendors. By prioritizing sustainable and healthy food options, institutions can promote the well-being of their community members while also contributing to environmental conservation efforts.', 'To ensure access to sustainable, healthy, and affordable food choices for all campus members, including vegetarian and vegan options, a program could be established to source locally produced ingredients, offer diverse menu selections, and collaborate with community partners for cost-effective solutions, with funding potentially sourced from campus dining budgets or sustainability grants.'),
(9, 'Access to food security knowledge', 4, '2_4_1', 'In section 2.4.1, there are a total of four Program and Project Activities (PPAs) focused on providing access to food security and sustainable agriculture and aquaculture knowledge, skills, or technology to local farmers and food producers. These extension activities play a crucial role in empowering local communities by equipping them with the necessary knowledge and tools to enhance food security and promote sustainable practices in agriculture and aquaculture. These initiatives may include training programs, workshops, demonstrations, or technology transfer projects aimed at improving agricultural productivity, enhancing resilience to environmental challenges, and fostering economic development in rural areas. Through these extension activities, stakeholders can build capacity, share best practices, and collaborate towards building more resilient and sustainable food systems.', 'To complete this section, you\'ll need to provide the title of the Program and Project Activity (PPA), a short description explaining what the PPA entails (such as training programs, workshops, or technology transfer initiatives), the total cost associated with implementing the PPA, and the source of funding for the PPA. '),
(10, 'Events for local farmers and food producers', 4, '2_4_2', 'In section 2.4.2, there are currently no events provided for local farmers and food producers to connect and transfer knowledge. This indicates a potential opportunity to create networking opportunities and knowledge-sharing platforms within the agricultural and food production community. Such events could include workshops, conferences, or field days where farmers and producers can exchange experiences, learn about new technologies and practices, and build collaborative relationships. By facilitating these events, organizations can promote innovation, enhance resilience, and foster sustainable development within the local agricultural sector.', 'To fill out the information for this Program and Project Activity (PPA), you can start by creating a title that succinctly describes the event, followed by a brief description outlining the purpose and format of the event. Then, specify the total cost of organizing the event and identify the funding source or allocation.'),
(11, 'Access of local farmers and food producers to University\r\nfacilities', 4, '2_4_3', 'The section \"2.4.3 Access of local farmers and food producers to University facilities\" aims to address the crucial need for enhancing the collaboration between universities and local farming communities to promote sustainable farming practices. Its primary objective is to facilitate access for local farmers and food producers to various resources and facilities available within universities. By leveraging these resources, farmers can improve their farming techniques, optimize resource usage, and enhance the overall sustainability of their operations.\n\nThis section underscores the significance of bridging the gap between academic knowledge and practical application in agriculture. It emphasizes the importance of universities in serving as hubs of expertise, research, and innovation that can directly benefit local farming communities. By providing access to university facilities, farmers gain opportunities to tap into cutting-edge technologies, research findings, and specialized equipment that can empower them to address challenges and adopt sustainable farming practices effectively.\n\nFurthermore, the section outlines specific types of university facilities that can be made accessible to local farmers and food producers. These facilities range from seed banks to agricultural engineering labs, soil and water testing laboratories, food science and nutrition labs, and renewable energy labs. Each of these facilities offers unique benefits and resources tailored to support various aspects of sustainable agriculture, including crop diversity, resource management, soil health, food safety, and energy efficiency.', 'This section is dedicated to local farmers and food producers who are interested in accessing university facilities to enhance their farming practices and promote sustainability in agriculture. Your input is invaluable in understanding your needs and preferences regarding access to these resources.'),
(12, 'Sustainable food purchases', 4, '2_4_4', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `sdg2_indicators`
--

CREATE TABLE `sdg2_indicators` (
  `topic_id` int(11) NOT NULL,
  `research_topic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sdg2_indicators`
--

INSERT INTO `sdg2_indicators` (`topic_id`, `research_topic`) VALUES
(1, 'Research on hunger'),
(2, 'Campus food waste'),
(3, 'Student and employee\r\nhunger'),
(4, 'National Hunger');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `2_1_1`
--
ALTER TABLE `2_1_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_2`
--
ALTER TABLE `2_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_3_1`
--
ALTER TABLE `2_3_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_3_2`
--
ALTER TABLE `2_3_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_3_3`
--
ALTER TABLE `2_3_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_3_4`
--
ALTER TABLE `2_3_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_3_5`
--
ALTER TABLE `2_3_5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_4_1`
--
ALTER TABLE `2_4_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_4_2`
--
ALTER TABLE `2_4_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `2_4_3`
--
ALTER TABLE `2_4_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `columnquestion`
--
ALTER TABLE `columnquestion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datasummary`
--
ALTER TABLE `datasummary`
  ADD PRIMARY KEY (`datasummary_id`),
  ADD KEY `part_id` (`part_id`);

--
-- Indexes for table `parttable`
--
ALTER TABLE `parttable`
  ADD PRIMARY KEY (`part_id`),
  ADD KEY `research_topic_id` (`research_topic_id`);

--
-- Indexes for table `sdg2_indicators`
--
ALTER TABLE `sdg2_indicators`
  ADD PRIMARY KEY (`topic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `2_1_1`
--
ALTER TABLE `2_1_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `2_2`
--
ALTER TABLE `2_2`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `2_3_1`
--
ALTER TABLE `2_3_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `2_3_2`
--
ALTER TABLE `2_3_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `2_4_3`
--
ALTER TABLE `2_4_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `columnquestion`
--
ALTER TABLE `columnquestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `datasummary`
--
ALTER TABLE `datasummary`
  MODIFY `datasummary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `datasummary`
--
ALTER TABLE `datasummary`
  ADD CONSTRAINT `datasummary_ibfk_1` FOREIGN KEY (`part_id`) REFERENCES `parttable` (`part_id`);

--
-- Constraints for table `parttable`
--
ALTER TABLE `parttable`
  ADD CONSTRAINT `parttable_ibfk_1` FOREIGN KEY (`research_topic_id`) REFERENCES `sdg2_indicators` (`topic_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
